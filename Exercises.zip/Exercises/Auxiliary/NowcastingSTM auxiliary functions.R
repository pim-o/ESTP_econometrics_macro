


#--------------------------------------------------------------------------------------
## select.model
#--------------------------------------------------------------------------------------
# function to select the right model specifications

select.model <- function(selection, series, regressors=NULL, initial.values.all)
{
#c("meas", "level", "slope", "seas", "scaling")
  periodicity <- tsp(series)[3]
  
  periodicity <- tsp(series)[3]
  

  if(selection==1){
    #modelname <- "Deterministic level model"
    modelname <- "det.  level"
   
    model <- SSModel(series ~ SSMtrend(1,Q=0),H=matrix(NA))
    if(is.null(regressors)==F) {
      model <- SSModel(series ~ SSMtrend(1,Q=0) + regressors,H=matrix(NA))
    }
    initial.values <- initial.values.all[1]
  }
  

  if(selection==2){
    #modelname <- "Local level model"
    modelname <- "stoch.level"
  
    model <- SSModel(series ~ SSMtrend(1,Q=list(matrix(NA))),H=matrix(NA))
    if(is.null(regressors)==F) {
      model <- SSModel(series ~ SSMtrend(1,Q=list(matrix(NA))) + regressors,H=matrix(NA))
    }
    initial.values <- initial.values.all[c(2,1)]
  }
  

  if(selection==3){
    modelname <- "det.  level + det.  slope (= classical regression)"
    model <- SSModel(series~SSMtrend(2,Q=list(0, 0)),H=matrix(NA))
    if(is.null(regressors)==F) {
      model <- SSModel(series~SSMtrend(2,Q=list(0, 0)) + regressors,H=matrix(NA))
    }
    initial.values <- initial.values.all[1]
   
  }
  

  if(selection==4){
    modelname <- "stoch.level + det.  slope"
    model <- SSModel(series~SSMtrend(2,Q=list(matrix(NA), 0)) ,H=matrix(NA))
    if(is.null(regressors)==F) {
      model <- SSModel(series~SSMtrend(2,Q=list(matrix(NA), 0)) + regressors,H=matrix(NA))
    }
    initial.values <- initial.values.all[c(2,1)]
  }
  

  if(selection==5){
    #modelname <- "Smooth trend model"
    modelname <- "det.  level + stoch.slope (=smooth trend)"
   
    model <- SSModel(series~SSMtrend(2,Q=list(0, matrix(NA))) ,H=matrix(NA))
    if(is.null(regressors)==F) {
      model <- SSModel(series~SSMtrend(2,Q=list(0, matrix(NA))) + regressors,H=matrix(NA))
    }
    initial.values <- initial.values.all[c(3,1)]
  }
  
  
  if(selection==6){
    #modelname <- "Local linear trend model"
    modelname <- "stoch.level + stoch.slope"

    model <- SSModel(series~SSMtrend(2,Q=list(matrix(NA), matrix(NA))),H=matrix(NA))
    if(is.null(regressors)==F) {
      model <- SSModel(series~SSMtrend(2,Q=list(matrix(NA), matrix(NA))) + regressors,H=matrix(NA))
    }
    initial.values <- initial.values.all[c(2,3,1)]
  }
  
  

  if(selection==7){
    #modelname <- "Deterministic level + det. seasonal model"
    modelname <- "det.  level +               det. seasonal"
 
    model <- SSModel(series~ -1 + SSMtrend(1,Q=0)
                     + SSMseasonal(periodicity, Q=0, sea.type="dummy")
                     ,H=matrix(NA))
    if(is.null(regressors)==F) {
      model <- SSModel(series~ -1 + SSMtrend(1,Q=0)
                       + SSMseasonal(periodicity, Q=0, sea.type="dummy")
                       + regressors ,H=matrix(NA))
    }
    initial.values <- initial.values.all[1]
  }
  
  

  if(selection==8){
    #modelname <- "Local level + deterministic seasonal model"
    modelname <- "stoch.level +               det. seasonal"
    
    model <- SSModel(series~ -1 + SSMtrend(1,Q=list(matrix(NA)))
                     +SSMseasonal(periodicity, diag(0,1), sea.type="dummy")
                     ,H=matrix(NA)  )
    if(is.null(regressors)==F) {
      model <- SSModel(series~ -1 + SSMtrend(1,Q=list(matrix(NA)))
                       +SSMseasonal(periodicity, diag(0,1), sea.type="dummy")
                       + regressors ,H=matrix(NA)  )
    }
    initial.values <- initial.values.all[c(2,1)]
  }
  
  

  if(selection==9){
    modelname <- "stoch.level + det.  slope + det. seasonal"
    
    
    model <- SSModel(series~SSMtrend(2,Q=list(matrix(NA), 0))
                     +SSMseasonal(periodicity, diag(0,1), sea.type="dummy")
                     ,H=matrix(NA))
    if(is.null(regressors)==F) {
      model <- SSModel(series~SSMtrend(2,Q=list(matrix(NA), 0))
                       + SSMseasonal(periodicity, diag(0,1), sea.type="dummy")
                       + regressors,H=matrix(NA))
    }
    initial.values <- initial.values.all[c(2,1)]
  }
  
  
  
  if(selection==10){
    #modelname <- "Smooth trend + det. seasonal model"
    modelname <- "det.  level + stoch.slope + det. seasonal (smooth trend + seas)"
    
    model <- SSModel(series~SSMtrend(2,Q=list(0, matrix(NA)))
                     +SSMseasonal(periodicity, diag(0,1), sea.type="dummy")
                     ,H=matrix(NA))
    if(is.null(regressors)==F) {
      model <- SSModel(series~SSMtrend(2,Q=list(0, matrix(NA)))
                       + SSMseasonal(periodicity, diag(0,1), sea.type="dummy")
                       + regressors,H=matrix(NA))
    }
    initial.values <- initial.values.all[c(3,1)]
  }
  
  

  if(selection==11){
    #modelname <- "Local linear trend + det. seasonal model"
    modelname <- "stoch.level + stoch.slope + det. seasonal"
    
    model <- SSModel(series~-1 +SSMtrend(2,Q=list(matrix(NA), matrix(NA)))
                     + SSMseasonal(periodicity, diag(0,1), sea.type="dummy")
                     ,H=matrix(NA)  )
    if(is.null(regressors)==F) {
      model <- SSModel(series~-1 +SSMtrend(2,Q=list(matrix(NA), matrix(NA)))
                       + SSMseasonal(periodicity, diag(0,1), sea.type="dummy")
                       + regressors,H=matrix(NA)  )
    }
    initial.values <- initial.values.all[c(2,3,1)]
  }
  
  
  
  
  
  
  
  ###########################
  # 12. Local level + (stoch.) seasonal model
  ###########################
  # y_t   = mu_t + gamma_t + epsilon_t
  # mu_t+1= mu_t + eta_t
  # gamma_t+1 = -gamma_t - ... + eta3_t
  ###########################
  if(selection==12){
    #modelname <- "Local level + stoch. seasonal model"
    modelname <- "stoch.level +               stoch.seasonal"
    
    model <- SSModel(series ~ -1 + SSMtrend(1,Q=list(matrix(NA)))
                     + SSMseasonal(periodicity, diag(NA,1), sea.type="dummy")
                     ,H=matrix(NA)  )
    if(is.null(regressors)==F) {
      model <- SSModel(series ~ -1 + SSMtrend(1,Q=list(matrix(NA)))
                       + SSMseasonal(periodicity, diag(NA,1), sea.type="dummy")
                       + regressors ,H=matrix(NA)  )
    }
    initial.values <- initial.values.all[c(2,4,1)]
  }
  
  
  
  ########################################
  # 13. Local level, det. slope + stoch. seasonal
  #########################################
  # y_t   = mu_t + gamma_t + epsilon_t
  # mu_t+1= mu_t + v_t + eta1_t
  # v_t+1 = v_t
  # gamma_t+1 = -gamma_t - ... + eta3_t
  ###########################
  if(selection==13){
    #modelname <- "Local level, det. slope + stoch. seasonal"
    modelname <- "stoch.level + det.  slope + stoch.seasonal"
    
    model <- SSModel(series~-1 +SSMtrend(2,Q=list(matrix(NA),0))
                     + SSMseasonal(periodicity, diag(NA,1), sea.type="dummy")
                     ,H=matrix(NA)  )
    if(is.null(regressors)==F) {
      model <- SSModel(series~-1 +SSMtrend(2,Q=list(matrix(NA),0))
                       + SSMseasonal(periodicity, diag(NA,1), sea.type="dummy")
                       + regressors,H=matrix(NA)  )
    }
    initial.values <- initial.values.all[c(2,4,1)]
    
  }
  
  
  
  
  ########################################
  # 14. Smooth trend  + stoch. seasonal model
  #########################################
  # y_t   = mu_t + gamma_t + epsilon_t
  # mu_t+1= mu_t + v_t
  # v_t+1 = v_t  + eta2_t
  # gamma_t+1 = -gamma_t - ... + eta3_t
  ###########################
  if(selection==14){
    #modelname <- "Smooth trend + stoch. seasonal model"
    modelname <- "det.  level + stoch.slope + stoch.seasonal (smooth trend + seas)"
    model <- SSModel(series~-1 +SSMtrend(2,Q=list(0, matrix(NA)))
                     + SSMseasonal(periodicity, diag(NA,1), sea.type="dummy")
                     ,H=matrix(NA)  )
    if(is.null(regressors)==F) {
      model <- SSModel(series~-1 +SSMtrend(2,Q=list(0, matrix(NA)))
                       + SSMseasonal(periodicity, diag(NA,1), sea.type="dummy")
                       + regressors,H=matrix(NA)  )
    }
    initial.values <- initial.values.all[c(3,4,1)]
    
  }
  

  
  
  ###############################################
  # 15. Local linear trend + stoch. seasonal model
  ################################################
  # y_t   = mu_t + gamma_t + epsilon_t
  # mu_t+1= mu_t + v_t + eta1_t
  # v_t+1 = v_t  + eta2_t
  # gamma_t+1 = -gamma_t - ... + eta3_t
  ###########################
  if(selection==15){
    #modelname <- "Local linear trend + seasonal model"
    modelname <- "stoch.level + stoch.slope + stoch.seasonal"
    model <- SSModel(series~-1 +SSMtrend(2,Q=list(matrix(NA), matrix(NA)))
                     + SSMseasonal(periodicity, diag(NA,1), sea.type="dummy")
                     ,H=matrix(NA)  )
    if(is.null(regressors)==F) {
      model <- SSModel(series~-1 +SSMtrend(2,Q=list(matrix(NA), matrix(NA)))
                       + SSMseasonal(periodicity, diag(NA,1), sea.type="dummy")
                       + regressors,H=matrix(NA)  )
    }
    initial.values <- initial.values.all[c(2,3,4,1)]
  }
  
  
  

 
  
  num.models <- 15  
  
  
  
  
return(list(modelname=modelname, model=model, initial.values=initial.values, num.models=num.models))


} #end function select.model






##-------------------------------------------------------------------------------------
## TS.estimate.parameters
##-------------------------------------------------------------------------------------
# function that optimises the model parameters using Maximum Likelihood


TS.estimate.parameters <- function(model, initial.values){

y <- model$y #orignele reeks, zelfde als series


fitmdl <- fitSSM(model=model, inits=initial.values, method='BFGS', hessian=TRUE)
LogLikValue <- -fitmdl$optim.out$value #geeft logLik
LogLikValue2 <- -fitmdl$optim.out$value/length(y) #zoals in Commandeur en Koopman

q <- sum(model$P1inf) #number of diffuse initial values in the state
w <- sum(is.na(model$Q)) + sum(is.na(model$H)) #total number of disturbance variances estimated
q; w
AIC <- (-2*LogLikValue+2*(q+w))
AIC2 <- AIC/length(y)  ##volgens commandeur en Koopman


LikAIC <- matrix(c(LogLikValue, AIC, LogLikValue2, AIC2), nrow=2,
            dimnames=list(c("LogLik", "AIC"), c("value", "value/n")))
print(LikAIC)
cat(paste("with: \nq = ", q, " (#diffuse states)", "\nw = ", w, " (#hyp.par)"  ))



sigma.sq <- exp(fitmdl$optim.out$par)  # maximum likelihood estimate of the stdev of the disturbances
sigma    <- sqrt(sigma.sq)

se <- fitmdl$optim.out$par*NA
try({ H <- fitmdl$optim.out$hessian
      cov <- solve(-H)  
      se  <- sqrt(diag(-cov)) #standard errors
     })


tvalues <- abs( fitmdl$optim.out$par / se )


volgorde <- c(length(sigma), 1:(length(sigma)-1))
if(length(sigma)>1) volgorde <- c(length(sigma), 1:(length(sigma)-1))
if(length(sigma)<=1) volgorde <- length(sigma)
sigma2 <- sigma[volgorde]
sigma.sq2 <- sigma.sq[volgorde]
tvalues2 <- tvalues[volgorde]


par.est <- t(rbind(sigma2, sigma.sq2, tvalues2))  #
dimnames(par.est)[[2]] <- c("sigma", "sigma^2", "t-value") #column names
cat("\n\nparameter estimates:\n"); print(par.est, quote=F)


return(list(fitmdl=fitmdl, LikAIC=LikAIC, sigma=sigma))

} # end function TS.estimate.parameters()






##-------------------------------------------------------------------------------------
## smooth
##-------------------------------------------------------------------------------------
# function that computes a smoothed signal and trend  



TS.smooth <- function(fittedmodel){


out_KFS    <- KFS(fittedmodel, filtering='state', smoothing='state')
signal3 <- signal(out_KFS, states="all")
signal <- signal3$signal
signalvar <- signal3$variance[1,1,]
signalsubset <- signal(out_KFS, states=c("level", "regression"))
signalsub <- signalsubset$signal
signalsubvar <- signalsubset$variance[1,1,]


state <- out_KFS$alphahat  
state[1,]
statevar <- sapply(1:dim(out_KFS$V)[1], function(i) out_KFS$V[i,i,])  
StateSE <- sqrt(statevar) #standaardfouten
state / StateSE #t-waarden
stvar <- matrix(statevar, nrow=dim(statevar)[1], dimnames=list(c(), dimnames(state)[[2]]))
mStSmo <- cbind(state, signal, stvar, signalvar)
mStSmo


state.est.1 <- t(rbind(state[1,], StateSE[1,], state[1,]/StateSE[1,]))
dimnames(state.est.1)[[2]] <- c("Estimate", "Std.Error", "t-value") #column names
cat("Smoothed values of states and standard errors at time n = 1:\n")
print(state.est.1, quote=F)

last <-dim(state)[1]
state.est.n <- t(rbind(state[last,], StateSE[last,], state[last,]/StateSE[last,]))
dimnames(state.est.n)[[2]] <- c("Estimate", "Std.Error", "t-value") #column names
cat("Smoothed values of states and standard errors at time n = ", last,":\n", sep="")
print(state.est.n, quote=F)

conf_series1 <- predict(fittedmodel, interval = "confidence", level = 0.95)
LB <- signal - qnorm(0.975)*sqrt(signalvar)
UB <- signal + qnorm(0.975)*sqrt(signalvar)
signalconf <- cbind(signal, LB, UB)
signalconf - conf_series1

LBtrend <- signalsub - qnorm(0.975)*sqrt(signalsubvar)
UBtrend <- signalsub + qnorm(0.975)*sqrt(signalsubvar)
signalsubconf <- cbind(trend=signalsub, LB=LBtrend, UB=UBtrend)


return(list(out_KFS=out_KFS, signal=signal, signalvar=signalvar, signalconf=signalconf,
            signalsub=signalsub, signalsubvar=signalsubvar, signalsubconf=signalsubconf,
            mStSmo=mStSmo))

} #end function TS.smooth()




##-------------------------------------------------------------------------------------
## nowcast
##-------------------------------------------------------------------------------------
# function to produce a nowcast for the target variable 
# 

#voor testen:
#fittedmodel <- ML$fitmdl$model

TS.nowcast <- function(fittedmodel, conf.level=0.95){

# KFS: Performs Kalman filtering and smoothing with exact diffuse initialization
# using univariate approach for exponential family state space models.
out_KFS    <- KFS(fittedmodel, filtering='state', smoothing='state')

#attributes(out_KFS)
#out_KFS$a          #predicted states
#out_KFS$t          #predictions of signal = zt at
#out_KFS$alphahat   #smoothed

signal_pred <- signal(out_KFS, states="all", filtered=TRUE)$signal  #one step ahead predictions

#signal_pred_var <- signal(out_KFS, states="all", filtered=TRUE)$variance[1,1,]  #variances
#modified sep 2022 to make sure signal_pred_Var is a time series:
signal_pred_var <- signal_pred*0+signal(out_KFS, states="all", filtered=TRUE)$variance[1,1,]  #variances

predictions <- predict(fittedmodel, filtered=TRUE, interval="confidence", level=conf.level) 

state_pred <- out_KFS$a  #smoothed estimates of state
statevar_pred <- sapply(1:dim(out_KFS$P)[1], function(i) out_KFS$P[i,i,])  #neemt diagonaalelementen en zet ze per state op een rij
StateSE_pred <- sqrt(statevar_pred) #standaardfouten

stvar_pred <- matrix(statevar_pred, nrow=dim(statevar_pred)[1], dimnames=list(c(), dimnames(state_pred)[[2]]))
mStpred <- cbind(state_pred, signal_pred, stvar_pred, signal_pred_var)

return(list(out_KFS=out_KFS, signal_pred=signal_pred, signal_pred_var=signal_pred_var, 
        predictions=predictions, mStpred=mStpred))


} #end function TS.nowcast()



##-------------------------------------------------------------------------------------
# make.graph
##-------------------------------------------------------------------------------------

make.graph <- function(reeks1, predictions1, signal1, titel, conf.level){

predictions2 <- window(predictions1, start=tsp(predictions1)[2]-1/tsp(predictions1)[3]) #laatste 2

verschuiving <- predictions2[1,2]  
nowcast <- window(predictions1, start=tsp(predictions1)[2]-1/tsp(predictions1)[3])

nowcast[1,1]  <- as.double(window(reeks1, start=tsp(predictions1)[2]-1/tsp(predictions1)[3], 
    end=tsp(predictions1)[2]-1/tsp(predictions1)[3]))
nowcast[1,2]  <- nowcast[1,1] - (nowcast[2,1]-nowcast[2,2])
nowcast[1,3]  <- nowcast[1,1] + (nowcast[2,1]-nowcast[2,2])

reeksen <- cbind(reeks1, nowcast)
signal1 <- window(signal1, end=tsp(signal1)[2]-1/tsp(signal1)[3])

ts.plot(cbind(reeks1, signal1, nowcast), col=c(4,4,2,2,2), lty=c(1,2,1,2,2), lwd=c(2,1,1,1,1),
  xlab="",ylab = "", main=titel )
legend('topleft', inset=0.01, cex=0.7, legend = c('original series', 'model estimate', 'nowcast',
                                                  paste0(conf.level*100, "% conf.int.")),
  col = c(4,4,2,2), lwd=c(2,1,1,1), lty = c(1,3,1,3))
}





##-------------------------------------------------------------------------------------
# TS.diagnostics
##-------------------------------------------------------------------------------------
# diagnostics for the smoothed model 


TS.diagnostics <- function(model.in, out, k=10, summary=TRUE){

out_KFS <- out
y <- out_KFS$model$y 
w2 <- sum(is.na(model.in$Q)) + sum(is.na(model.in$H)) #total number of disturbance variances estimated

#standardized prediction errors
st.p.err <- out_KFS$v/sqrt(out_KFS$F[1,])
#rstandard(out_KFS) levert hetzelfde
q2 <- sum(model.in$P1inf)
st.p.err <- st.p.err[(q2+1):length(st.p.err)]  
if(summary==F) plot(st.p.err, main="standardized prediction errors", ylab="", type="l")


#1.----- independence
n <- length(st.p.err)
#k <- 10
acf.err <- acf(st.p.err, k, plot=F, na.action =na.pass)$acf[-1]
Q.statistic <- n*(n+2)*sum(acf.err^2/ (n - seq(1:k)))
Q.critical <- qchisq(.95, df=k- w2 + 1)
Q.statistic
Q.critical

significant.errors <- acf.err > 2/sqrt(length(y))
if(summary==F){
cat("------------------------------------\n")
cat("----Independence:----")
cat("\nautocorrelations of standardised prediction errors\n")
print(data.frame(cbind(autocorr=round(acf.err,3),significant=significant.errors), row.names=seq(1,k)), quote=F)
cat(paste("(95%-confidence limit for autocorr. =", round(2/sqrt(length(y)),3),")"))

cat(paste("\n\nBox-Ljung statistic: Q(", k,") = ", round(Q.statistic,3), sep=""))
cat(paste("\nif Q(", k, ") < Chi-sq(", k-w2+1, ",0.05) = ",  round(Q.critical,3) , sep=""))
cat(paste("\nthen first", k,"autocorrelations do not significantly deviate from zero"))
}

Indep.satisfied <- ifelse(Q.statistic<Q.critical, "+", "-")
r.critical  <- 2/sqrt(length(y))
r1.satisfied <- ifelse(abs(acf.err[1]) <  r.critical , "+", "-")
rf.satisfied <- ifelse(abs(acf.err[tsp(y)[3]])< r.critical , "+", "-")


#2.----- homoscedasticity
n2 <- length(y)
h <- round((n2 - q2)/3)
lasth <- (tail(st.p.err, h))^2
firsth <- (head(st.p.err,h))^2
H.statistic <- sum(lasth, na.rm=T)/sum(firsth, na.rm=T)
paste.H <- paste("H(", h, ")", sep="")
if(H.statistic<1) {
  H.statistic <- 1/H.statistic
  paste.H <- paste("1/H(", h, ")", sep="")
  }
H.critical <- qf(0.975,h,h)
H.satisfied <- ifelse(H.statistic<H.critical, "+", "-")
if(summary==F){
cat("\n------------------------------------")
cat("\n----Homoscedasticity:----")
cat(paste("\nHomoscedastic if H(", h, ") = ", round(H.statistic,3),
            " < F(0.975,", h, ",", h, ") = ", round(H.critical,3), sep=""))
}


#3.----- normality
dif <- st.p.err - mean(st.p.err, na.rm=T) 
S   <- mean(dif^3, na.rm=T) / sqrt(mean(dif^2, na.rm=T)^3 )  #Skewness
K   <- mean(dif^4, na.rm=T) / mean(dif^2, na.rm=T)^2 #Kurtosis
N.statistic <- (S^2/6 + (K-3)^2/24)*length(dif)
N.critical  <- qchisq(.95, df=2)
N.satisfied <- ifelse(N.statistic<N.critical, "+", "-")
if(summary==F){
cat("\n------------------------------------")
cat("\n----Normality:----")
cat(paste("\nNormally distributed if N = ", round(N.statistic,3),
            " < Chi-sq(2,0.95) = ", round(N.critical,3), sep=""))
}

#4.----- Summary
Assumption <- c("Independence", "","", "Homoscedasticity", "Normality")
Statistic <- c(paste("Q(",k,")", sep=""), "r(1)", paste("r(",tsp(y)[3], ")",sep=""),
                  paste.H, "N")
Value <- c(round(Q.statistic,3), round(acf.err[1],3),round(acf.err[tsp(y)[3]],3),
              round(H.statistic,3) , round(N.statistic,3) )
r.crit <- paste("+/-", round(r.critical,3), sep="")
Critical_value <- c(round(Q.critical,3), r.crit,r.crit, round(H.critical,3),round(N.critical,3))
Assumption_satisfied<- c(Indep.satisfied,r1.satisfied, rf.satisfied, H.satisfied, N.satisfied)
summarydiag <- cbind(Statistic,Value,Critical_value,Assumption_satisfied)
dimnames(summarydiag)[[1]] <- Assumption
cat("\n------------------------------------")
cat("\n----Diagnostics summary:----\n")
print(summarydiag, quote=F)


residuals <- y - signal(out_KFS, states="all" )$signal
if(summary==F) plot(residuals, main="residuals")

} #end function TS.diagnostics()







##-------------------------------------------------------------------------------------
# compare.models
##-------------------------------------------------------------------------------------
compare.models <- function(series, regressor=NULL, initial.values.all){
  num.models <- select.model(selection = 1, series, regressors=NULL, initial.values.all)$num.models
  AICs <- data.frame(cbind( c(1:num.models), rep(NA, num.models), rep(NA, num.models)))
  names(AICs) <- c("model_nr","AIC", "model_name")
  
  AIConly <- c()
  for(i in 1:num.models){
    cat("------------------------")
    cat("\nmodel = ", i, "\n")
    modelsel <- select.model(selection=i, series, regressor, initial.values.all)
    print(modelsel$modelname)
    AICs$model_name[i] <- modelsel$modelname
    #AICs[[i]] <- NA
    AIConly[i] <- NA
    a <-  try( { ML <- TS.estimate.parameters(modelsel$model, modelsel$initial.values)$LikAIC
    AICs$model_nr[i] <- i
    AICs$AIC[i] <- ML[2,1]
    AIConly[i] <- ML[2,1] })
  }
  cat("------------------------")
  cat("\n Summary: AIC's per model\n"); print(AICs, right=F)
  min.AIC <- min(AIConly, na.rm=T)
  opt.model <- which(AIConly==min.AIC)
  opt.model.name <- select.model(selection=opt.model, series, regressor, initial.values.all)$modelname
  cat("minimum AIC achieved for model", opt.model, "(AIC =", min.AIC, ",", opt.model.name,")")
  return(list(opt.model=opt.model))
}






##-------------------------------------------------------------------------------------
# print.summary
##-------------------------------------------------------------------------------------
printsummary <- function(modelsel, series, regessor){
cat("model      : ",  modelsel$modelname,
    "\nseries     : ", dimnames(series)[[2]],
    "\nregressoren: ", paste(dimnames(regressor)[[2]], collapse=", "),
    "\n# obs.     : ", length(series),
    "\nstart      : ", floor(tsp(series)[1]),".", tsp(series)[1]%%1*tsp(series)[3]+1,
    "\nend        : ", floor(tsp(series)[2]), ".", tsp(series)[2]%%1*tsp(series)[3]+1,
    "\nperiodicity: ", tsp(series)[3], sep="")
}


##-------------------------------------------------------------------------------------
# set.initials
##-------------------------------------------------------------------------------------
set.initials <- function(a,b,c,d,e){
 init <- c(a,b,c,d,e)
 names(init) <- c("meas", "level", "slope", "seas", "scaling")
return(init = init)
}



##-------------------------------------------------------------------------------------
##-------------------------------------------------------------------------------------
plotSM <- function(series, trendlijn, naam){
  #reeks + trendlijn + marge
  ts.plot(cbind(series, trendlijn), col = c(2,4 , 4, 4), lwd=c(2,2,1,1), lty=c(1,1,3,3), xlab="",ylab = "",
          main = naam)
  legend('bottomleft', inset=0.01, cex=0.7,
         legend = c('original series', 'smoothed trend', '95% conf.int.'),
         col = c(2, 4, 4), lwd=c(2,2,1), lty = c(1, 1,3))
}



##-------------------------------------------------------------------------------------
#function to generate all combinations of regressors 
##-------------------------------------------------------------------------------------

generate_models = function (regressors = reg){
  
  models = c()
  if (length(regressors)>=1){
    regressorss=list()
    for (i in 1:length(regressors)){
      regressorss[[i]]=regressors
    }
    X=expand.grid(regressorss)
    X=unique(t(apply(X,1,sort)))
    Y=list()
    Y[[1]]=NULL
    for (i in 1:nrow(X)){
      Y[[i+1]]=unique(X[i,])  
    }
    models=unique(Y)
  }
  return(models)
}
