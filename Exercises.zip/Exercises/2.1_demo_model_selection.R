source("D1p5_NowcastingSTM_part1.R")


regressor <- c()

startingvalues.all <- set.initials(-0.1, 1, 0, 0.5, 0) 


#target_series <- data1[, c("Index_Bank")] # series for Banking 
target_series <- data1[, c("Index_Insurance")] 


compare.models(target_series, regressor, startingvalues.all)$opt.model 



modelnumber <- 5


modelsel <- select.model(modelnumber, target_series, regressor,startingvalues.all)
printsummary(modelsel, target_series, regressor)
ML <- TS.estimate.parameters(modelsel$model, modelsel$initial.values)
SM <- TS.smooth(ML$fitmdl$model)
TS.diagnostics(modelsel$model, SM$out_KFS )
signal <- SM$signalconf #trend plus season
plotSM(target_series, signal, "Banking")

signal.without.outlier <- signal


















# Now let's remove an outlier 
#-------------------
outlier1  <- rep(0,length(target_series))
outlier1[12] <- 1  # 2012Q4 for Insurance
outlier1

regressor <- outlier1


modelnumber <- 5

modelsel <- select.model(modelnumber, target_series, regressor,startingvalues.all)
printsummary(modelsel, target_series, regressor)
ML <- TS.estimate.parameters(modelsel$model, modelsel$initial.values)
SM <- TS.smooth(ML$fitmdl$model)
TS.diagnostics(modelsel$model, SM$out_KFS )
signal <- SM$signalconf #trend plus season
plotSM(target_series, signal, "Banking")


ts.plot(cbind(target_series, signal), col = c(2,4 , 4, 4), lwd=c(2,2,1,1), lty=c(1,1,3,3), xlab="",ylab = "",
        main = "Banking")
ts.plot(cbind(target_series, signal,signal.without.outlier), col = c(2,4 , 4, 4,1,1,1), lwd=c(2,2,1,1,2,1,1), lty=c(1,1,3,3,1,3,3), xlab="",ylab = "",
        main = "")
legend('bottomright', inset=0.01, cex=0.7,
       legend = c('original series', 'model with outlier', 'model without outlier'),
       col = c(2, 4, 1), lwd=c(2,2,2), lty = c(1, 1,1))

