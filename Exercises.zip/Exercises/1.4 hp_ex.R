#install packages
install.packages('hpfilter')
install.packages('deseats')


### load packages ###
library(tidyverse)
library(hpfilter)
library(deseats)

### load data ###
GDP <- hpfilter::GDPEU


### HP filter ###
GDP_nodate <- GDP[,2] #remove date such that it fits the hp2() format
lambda_input <- 1600 # set HP filter
hpfilter_trend <- hp2(GDP_nodate, lambda = lambda_input)

#create hp dataset
hpfilter_df_trend <- data.frame(
  date = GDP$date,
  gdp = GDP$gdp,
  hp_trend = hpfilter_trend$gdp
  )

#calculate cycle based on trend and og data
hpfilter_df <- hpfilter_df_trend %>%
  mutate(hp_cycle = gdp - hp_trend) %>%
  pivot_longer(
    c('gdp', 'hp_trend', 'hp_cycle'),
    names_to = 'component',
    values_to = 'value'
    )

#plot trend
hpfilter_df %>%
  filter(component %in% c("gdp", "hp_trend")) %>%
  ggplot(aes(
    x = date,
    y = value,
    group = component,
    colour = component
  )) +
  geom_line(linewidth = 0.8, alpha = 0.8) +
  geom_point(size = 1.5, alpha = 0.8) +
  labs(
    title = "Line plot by group",
    subtitle = "Development of value over time",
    x = "Date",
    y = "Value",
    colour = "Group"
  ) +
  theme_minimal()

#plot cycle
hpfilter_df %>%
  filter(component %in% c("hp_cycle")) %>%
  ggplot(aes(
    x = date,
    y = value,
    group = component,
    colour = component
  )) +
  geom_line(linewidth = 0.8, alpha = 0.8) +
  geom_point(size = 1.5, alpha = 0.8) +
  labs(
    title = "Line plot by group",
    subtitle = "Development of value over time",
    x = "Date",
    y = "Value",
    colour = "Group"
  ) +
  theme_minimal()


#remove excess dataframes
rm(GDP_nodate, hpfilter_df_trend, hpfilter_trend)
