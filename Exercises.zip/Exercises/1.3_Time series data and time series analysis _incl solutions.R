##############################################################################################
# Time series data and applications 
##############################################################################################

#######
# Author : Pim Ouwehand (StatNL)

#######


rm(list=ls())
gc()


#-------------------------------------------------
# Loading packages etc.
#-------------------------------------------------


library(dplyr)
library(corrplot)
library(dplyr)
library(tidyr)
library(zoo)
library(tseries)
library(forecast)




#-------------------------------------------------
# read and prepare data
#-------------------------------------------------

data_month <- read.csv2('data/economic_series_month.csv')
data_quarter <- read.csv2('data/economic_series_quarter.csv')

# combine both datasets
data <- full_join(data_month, data_quarter, by='Period') 
data_num <- data %>% select(-Period) 

# for this exercise, we will interpolate the three quarterly series
# so that all series have monthly frequency
data_interp <- na.approx(data_num, na.rm = FALSE)
data_interp <- as.data.frame(data_interp)

# to avoid problems due to division by zero:
data_interp[data_interp == 0 ] = 0.01

# percentage change
data_growth <- data_interp %>%
  mutate(across(everything(), ~ (. / lag(.) - 1) * 100)) %>%
  drop_na() 




# =============================================================
# 1. Stationarity
# =============================================================



# *-*-*-*-*-*-*-*-*-*-*-*-*-*-
#EXERCISE: 
# *-*-*-*-*-*-*-*-*-*-*-*-*-*-
# try to make the following series stationary 
# use (seasonal) differencing, perhaps take a log 

data(AirPassengers)
ap <- AirPassengers

adf.test(ap)
#adf.test has a p-value below 0.05, so series seems stationary,
#but adf.test always includes a linear trend in the test regression. 
#The alternative hypothesis is therefore "trend-stationary," not "stationary."

library(urca)
# No constant, no trend
summary(ur.df(ap, type = "none", lags = 12))
#fail to reject the unit-root null hyp., so the test finds the series non-stationary.



# *-*-*-*-*-*-*-*-*-*-*-*-*-*-
# Solution: 
# *-*-*-*-*-*-*-*-*-*-*-*-*-*-
# Log-transform first (variance grows with the trend, so stabilize it)
log_ap <- log(ap)

# Regular differencing removes the trend
diff_ap <- diff(log_ap)

# Seasonal differencing removes the yearly pattern
seasonal_diff_ap <- diff(diff_ap, lag = 12)

# regular + Seasonal differencing removes the yearly pattern
diff_seasonal_diff_ap <- diff(diff_ap, lag = 12)

par(mfrow = c(3, 1), mar = c(4, 4, 3, 1))

plot(ap, main = "AirPassengers (raw) - trend + seasonality + growing variance",
     ylab = "Passengers")

plot(diff_ap, main = "After log + 1st difference - trend removed, seasonality remains",
     ylab = "Delta log(passengers)")
abline(h = 0, lty = 2, col = "gray")

plot(seasonal_diff_ap, main = "After log + 1st diff + seasonal diff - stationary",
     ylab = "Delta_12 Delta log(passengers)")
abline(h = 0, lty = 2, col = "gray")

par(mfrow = c(1, 1))

adf.test(diff_ap)            # borderline / may still show seasonal structure
adf.test(seasonal_diff_ap)   # clearly stationary

summary(ur.df(log_ap, type = "none", lags = 12)) #not stationary
summary(ur.df(diff_ap, type = "none", lags = 12)) #still nonstationary
summary(ur.df(seasonal_diff_ap, type = "none", lags = 12)) #non stationary
summary(ur.df(diff_seasonal_diff_ap, type = "none", lags = 12)) #stationary










# =============================================================
# 3. Cointegration
# =============================================================




# *-*-*-*-*-*-*-*-*-*-*-*-*-*-
# EXERCISE: 
# *-*-*-*-*-*-*-*-*-*-*-*-*-*-

# consumption-quote
# prove that consumption and income are both nonstationary, but cointegrated.


data_Inc_Cons <- read.csv2("data/CBS_Consumption_Income.csv")  
#https://opendata.cbs.nl/#/CBS/nl/dataset/85881NED/table?ts=1784549394056


# ---1. define time series ---
cons_ts <- ts(data_Inc_Cons$Consumption, start = c(1999, 1), frequency = 4)
inc_ts  <- ts(data_Inc_Cons$Income,    start = c(1999, 1), frequency = 4)

# --- 2. log -transform  ---
log_cons <- log(cons_ts)
log_inc  <- log(inc_ts)

plot.ts(cbind(log_cons, log_inc), plot.type = "single",
        col = c("steelblue", "firebrick"),
        main = "Consumption and income (log)")
legend("topleft", legend = c("consumption", "income"),
       col = c("steelblue", "firebrick"), lty = 1)



#use this:
# --- step 1. first test for non-stationarity
adf.test(x)  # H0: non-stationary (unit root): p>0.05
adf.test(y)
adf.test(diff(x))  # first diff should be stationary p<0.05
adf.test(diff(y))

# --- Step 2: Engle-Granger test
po.test(cbind(y, x))  # Phillips-Ouliaris test  
  



# *-*-*-*-*-*-*-*-*-*-*-*-*-*-
# SOLUTION: 
# *-*-*-*-*-*-*-*-*-*-*-*-*-*-

# they have a relatively low correlation:
cor(diff(log_cons), diff(log_inc))
# diff taken to avoid spurious correlation.


# What problem do you see? 
# > income peaks every year in Q2. (this is because holiday allowances are paid in Q2 in the Netherlands)
# cointegration works with I(1) processes, but this one is probably I(1)_4   
# So conclusion about cointegration will be biased.


# --- 3. deal with seasonality  ---

# We have a couple of options:

# option 1. seasonally adjust the series
library(seasonal)
inc_sa <- final(seas(inc_ts))  # seasonally adjusted 
cons_sa <- final(seas(cons_ts))
plot.ts(cbind(cons_ts, inc_sa), plot.type = "single", col = c("grey", "firebrick"),
        main = "seasonally adjusted income and consumption")
# --- log -transform  ---
log_cons <- log(cons_sa)
log_inc  <- log(inc_sa)
#next proceed below with step 4.

# option 2. include seasonal dummies in regression for the Engle-Granger test 
# see below at step 6
# option 3. take seasonal differences. However, this will alter the interpretation of the results 


# --- Step 4: stationarity criteria ---
adf.test(log_cons) #raw series is not stationary (p>0.05)
adf.test(log_inc)
adf.test(diff(log_cons)) #after taking first differences, it becomes stationry (p<0.05)
adf.test(diff(log_inc))

# --- Step 5: cointegration test ---
po.test(cbind(log_cons, log_inc))

# --- Step 6: Engle-Granger,  ---
model <- lm(log_cons ~ log_inc)
adf.test(residuals(model))

#in case we work with seasonal dummies, we get:
quarter <- factor(cycle(cons_ts))  # 1,2,3,4
model <- lm(log_cons ~ log_inc + quarter)
adf.test(residuals(model))





# =============================================================
# 5. Temporal relations: leading/lagging series
# =============================================================





# ------------------------------------------------------------
# Granger causality test 
# ------------------------------------------------------------
# Tests whether past values of x help predict y, beyond y's own past.
# install.packages("lmtest") if not already installed.

library(lmtest)


data_econ <- data_interp %>% drop_na() 

adf.test(data_econ$Consumerconfidence)
adf.test(data_econ$GDP)
adf.test(diff(data_econ$Consumerconfidence))
adf.test(diff(data_econ$GDP))
# after differencing they are clearly (p=0.01) stationary
# so we work with the differenced series:
gdp_diff <- diff(data_econ$GDP)
consumerconfidence_diff <- diff(data_econ$Consumerconfidence)

# Does the consumer confidence Granger-cause GDP?
grangertest(gdp_diff ~ consumerconfidence_diff, order = 6)

# or the other way round?
grangertest(consumerconfidence_diff ~ gdp_diff, order = 6)

# so consumerconfidence Granger-causes GDP




# *-*-*-*-*-*-*-*-*-*-*-*-*-*-
# EXERCISE: 
# *-*-*-*-*-*-*-*-*-*-*-*-*-*-
library(ggplot2)
data(economics)
# Data: `economics` dataset from the ggplot2 package.
# Real monthly US macroeconomic series sourced from FRED
# (Federal Reserve Economic Data), 1967-2015.

# we study two series:
# pce : personal consumption expenditure 
# unemploy: number unemployed

par(mfrow = c(2, 1), mar = c(3, 4, 2, 1))
plot(economics$date, economics$pce, type = "l", col = "steelblue",
     xlab = "", ylab = "PCE (billions USD)",
     main = "Personal consumption expenditures")
plot(economics$date, economics$unemploy, type = "l", col = "darkorange",
     xlab = "", ylab = "Unemployed (thousands)",
     main = "Number of unemployed")
par(mfrow = c(1, 1))

# convert to time series objects (monthly data)
pce_ts      <- ts(economics$pce,      start = c(1967, 7), frequency = 12)
unemploy_ts <- ts(economics$unemploy, start = c(1967, 7), frequency = 12)


# Question:
# At which lag does the strongest correlation occur?
# Is it positive or negative? What does the sign tell you about
# which series leads and which one lags?

# Question:
# Is the peak correlation positive or negative in value?
# What would a negative correlation mean here, economically?
# (Think about what happens to unemployment when people save more.)

# Question:
# Based on the p-values, which direction (if either) shows
# significant Granger causality? Does this match the lag you
# found in the CCF plot?



# *-*-*-*-*-*-*-*-*-*-*-*-*-*-
# SOLUTION: 
# *-*-*-*-*-*-*-*-*-*-*-*-*-*-

# both tests require stationary series, so first test this:
adf.test(pce_ts)  
adf.test(unemploy_ts)
adf.test(diff(pce_ts))
adf.test(diff(unemploy_ts))
# after differencing they are clearly (p=0.01) stationary
# so we work with the differenced series:
pce_ts_diff <- diff(pce_ts)
unemploy_ts_diff <- diff(unemploy_ts)



par(mar=c(2,4,4,1)) #bottom left, top, right
ccf_result <- ccf(pce_ts_diff, unemploy_ts_diff,
                  lag.max = 24,
                  main = "Cross-correlation: savings rate vs. unemployment")
# Extract the lag with the strongest correlation (by absolute value)
ccf_result$lag[which.max(abs(ccf_result$acf))] # best lag
ccf_result$acf[which.max(abs(ccf_result$acf))] # best correlation


# Does the savings rate Granger-cause unemployment?
grangertest(unemploy_ts_diff ~ pce_ts_diff, order = 6)
# p value is very small so yes there is causality

# Does unemployment Granger-cause the savings rate?
grangertest(pce_ts_diff ~ unemploy_ts_diff, order = 6)
# p value is a bit higher


# this causality also makes sense:
# consumption declines before unemployment rises.













