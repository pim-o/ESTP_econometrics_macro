# =========================
# PRESENTATION: ECONOMETRIC MODELS
# =========================

# =========================
# 1) Packages
# =========================
packages <- c("eurostat", "dplyr", "tidyr", "stringr", "purrr", "readr","ggplot2", "broom", "car", "lmtest", 
              "sf", "spdep", "giscoR", "httr2", "curl", "AER", "ivreg", "MASS", "gmm", "quantreg")
to_install <- packages[!packages %in% installed.packages()[, "Package"]]
if (length(to_install) > 0) install.packages(to_install)

library(curl)
library(httr2)
library(eurostat)
library(dplyr)
library(tidyr)
library(stringr)
library(purrr)
library(readr)

library(ggplot2)
library(broom)
library(car)
library(lmtest)
library(sf)
library(spdep)
library(giscoR)
library(AER)
library(ivreg)
library(MASS)
library(gmm)
library(quantreg)

options(eurostat_update = TRUE)

# =========================
# 2) Data preparation and transformation
# =========================
data_latest <- read_csv("F:/SOSR/ESTP Econometrics for Macroeconomic Statistics/data/eurostat_regional_data.csv")
View(data_latest)

# Instrumental variable: tertiary education
edu_raw <- get_eurostat("edat_lfse_04", time_format = "num")

# Check structure
names(edu_raw)
unique(edu_raw$unit)
unique(edu_raw$sex)
unique(edu_raw$age)

# Keep one value per NUTS2 region
edu_iv <- edu_raw %>%
  filter(
    TIME_PERIOD == 2024,
    nchar(geo) == 4,
    !str_detect(geo, "_"),
    sex == "T",
    age == "Y25-64",
    unit == "PC"
  ) %>%
  transmute(
    geo,
    tertiary_education = values
  ) %>%
  group_by(geo) %>%
  summarise(
    tertiary_education = first(na.omit(tertiary_education)),
    .groups = "drop"
  )

data_latest <- data_latest %>%
  left_join(edu_iv, by = "geo")

# transform - add log
data_model <- data_latest %>%
  mutate(
    ln_gdp = log(gdp_eur_per_inhab),
    ln_den = log(population_density)
  ) %>%
  filter(
    is.finite(unemployment),
    is.finite(ln_gdp),
    is.finite(htc),
    is.finite(serv),
    is.finite(ln_den),
    is.finite(tertiary_education)
  ) %>%
  rename(
    unemp = unemployment,
    gdp = gdp_eur_per_inhab,
    den = population_density
  )
View(data_model)

# =========================
# 3) OLS AND ITS DIAGNOSTICS: SLIDE 6-8 and 10-12
# =========================
ols_model <- lm(
  unemp ~ gdp + htc + serv + den,
  data = data_model
)

# show results
summary(ols_model)

############################################################################################################################
# INTERPRETATION OF RESULTS: 

# F-statistics: Does the model as a whole explain unemployment better than a model without explanatory variables?
# Null hypothesis: Betas = 0
# F-statistics = ?; p-value = ?

# Estimated Coefficients (Estimate): How does each explanatory variable affect unemployment?
# Sign (+ / −) indicates the direction of the relationship.
# Magnitude indicates the size of the effect.
# GDP and population density → no clear interpretation.
# HTC and SERV → interpreted as percentage-point changes.
# Conclusion: Which economic factors have the greatest potential impact on regional unemployment?
# Beta1 = ?; Beta2 = ?; Beta3 = ?; Beta4 = ?

# Beta2 the increase of 1% in employment in the high-tech sector is associated with an approximately ??? 
# percentage-point change in the unemployment rate

# Beta3 the increase of 1% in employment in the service sector is associated with an approximately ???
# percentage-point change in the unemployment rate

# How precisely are the coefficient estimated?
# Small standard error → precise estimate.
# Large standard error → high uncertainty.
# Conclusion: Estimates with smaller uncertainty provide more reliable evidence for decision-making.
# Std. Error Beta1 = ?; Std. Error Beta2 = ?; Std. Error Beta3 = ?; Std. Error Beta4 = ?

# t-statistics and p-value: Is the estimated effect substantially different from zero?
# Large absolute t-values indicate stronger statistical evidence.
# p-value: Could the observed effect have occurred by random chance?
# <0.001	Very strong evidence
# <0.01	Strong evidence
# <0.05	Statistically significant
# >0.05	Insufficient evidence
# Conclusion: Variables with statistically significant coefficients provide stronger empirical support for policy conclusions.
# p-value Beta1 = ?; p-value Beta2 = ?; p-value Beta3 = ?; p-value Beta4 = ?

# Residual Standard Error (RSE): How accurately does the model predict unemployment?
# The RSE measures the typical prediction error.
# On average, the predicted unemployment differs from the observed unemployment by approximately ??? percentage points.
# Smaller values indicate better predictive performance.
# RSE = ?

# Multiple and adjusted R-squared: How much of the regional variation in unemployment is explained by the model?
# How well does the model perform after accounting for the number of explanatory variables?
# The explanatory variables account for ?% of the observed variation in regional unemployment.
# Higher values indicate better explanatory power.

# Akaike Information Criterion (AIC): Which competing model provides the best balance between goodness-of-fit and model complexity?
# Lower AIC values indicate a preferred model. AIC has no absolute interpretation.
# It is meaningful only when comparing two or more competing models estimated on the same dataset.

# No single statistic determines whether a model is "good." 
# Model evaluation should consider statistical significance, explanatory power, predictive accuracy, 
# diagnostic assumptions, and economic plausibility together.
############################################################################################################################

##################################################################################################################
# OPTIONAL
# nicer coefficient table
View(tidy(ols_model))
# model fit statistics
View(glance(ols_model))
# fitted values (y hat)
data_model <- data_model %>%
  mutate(
    fitted_unemployment_ols = fitted(ols_model),
    residuals_ols = residuals(ols_model)
  )

# plot observed vs fitted values
ggplot(data_model, aes(x = fitted_unemployment_ols, y = unemp, label = geo)) +
  geom_point(alpha = 0.7, size = 2) +
  geom_text(vjust = -0.6, size = 2.5, check_overlap = TRUE) +
  geom_abline(intercept = 0, slope = 1, linewidth = 1) +
  labs(
    title = "OLS Model: Observed vs Estimated Unemployment",
    x = "Estimated unemployment rate (%)",
    y = "Observed unemployment rate (%)"
  ) +
  theme_minimal()
# The closer the points are to the diagonal line, the better the model explains regional unemployment differences. 
# Points above the line represent regions where actual unemployment is higher than predicted by the model. 
# Points below the line represent regions where actual unemployment is lower than predicted.
##################################################################################################################

# DIAGNOSTICS - GRAPHS: SLIDE 11
par(mfrow=c(2,2))
plot(ols_model)
par(mfrow=c(1,1))

# SLIDE 12
# Multicollinearity: Variance Inflation Factor
vif(ols_model)
# VIF	Interpretation
# <5	 acceptable
# 5-10 moderate
# >10	 severe multicollinearity

# Heteroskedasticity: Breusch–Pagan test 
bptest(ols_model)
# H0: Var(εi)=σ2 vs H1: Var(εi)/=σ2
# p-value > 0.05 ✔ homoscedasticity
# OLS OK p-value < 0.05 ✔ heteroskedasticity

# Spatial autocorrelation: Moran's I test (requires spatial coordinates)
# NUTS2 polygons
url <- "https://gisco-services.ec.europa.eu/distribution/v2/nuts/shp/NUTS_RG_20M_2021_4326.shp.zip"
download.file(
  url,
  destfile = "NUTS_RG_20M_2021_4326.shp.zip",
  mode = "wb"
)

unzip("NUTS_RG_20M_2021_4326.shp.zip", exdir = "nuts_shp")

nuts2 <- st_read("nuts_shp/NUTS_RG_20M_2021_4326.shp") |>
  dplyr::filter(LEVL_CODE == 2)

nuts2 <- nuts2 %>%
  filter(NUTS_ID %in% data_model$geo)

nuts2 <- left_join(
  nuts2,
  data_model,
  by=c("NUTS_ID"="geo")
)

# Queen contiguity
nb <- poly2nb(nuts2)

lw <- nb2listw(
  nb,
  style = "W",
  zero.policy = TRUE
)

moran.test(
  nuts2$residuals_ols,
  lw,
  zero.policy = TRUE
)
# Hypotheses H0: Cov(εi,εj)=0
# No spatial autocorrelation, if p-value > 0.05
# If p-value < 0.05, residuals remain spatially correlated. OLS assumption violated.

# OPTIONAL: Map of OLS residuals
ggplot(nuts2) +
  geom_sf(aes(fill = residuals_ols), color = "white", linewidth = 0.1) +
  scale_fill_gradient2(
    name = "OLS residual",
    low = "blue",
    mid = "white",
    high = "red",
    midpoint = 0
  ) +
  labs(
    title = "Spatial Distribution of OLS Residuals",
    subtitle = "Positive residuals: observed unemployment is higher than predicted",
    caption = "Source: Eurostat regional data; author's calculation"
  ) +
  theme_minimal()
# The map shows where the OLS model systematically overpredicts or underpredicts unemployment.
# Red regions have positive residuals, meaning that observed unemployment is higher than predicted by the model.
# Blue regions have negative residuals, meaning that observed unemployment is lower than predicted.
# If similar residuals are spatially clustered, this may indicate spatial autocorrelation, suggesting that 
# the independence assumption of OLS is violated and that a spatial model may be appropriate.

# Endogeneity: Hausman test (requires IVs)
# Endogeneity cannot generally be tested without external instrumental variables.
# IV 2-stage Least Square Estimator
iv_model <- ivreg(unemp ~ ln_gdp + htc + serv + ln_den | tertiary_education + htc + serv + ln_den, 
                  data = data_model)
summary(iv_model, diagnostics=TRUE)
# Wu-Hausman test test: is endogeneity actually present?
# Null hypothesis H0: The explanatory variable is exogenous.
# Result	      Interpretation
# p-value > 0.05	OLS is appropriate
# p-value < 0.05	Endogeneity detected → IV estimation preferred

# =========================
# 4) WEIGHTED OLS: SLIDE 13
# =========================
wls_model <- lm(
  unemp ~ gdp + htc + serv + den,
  data = data_model, 
  weights = den / mean(den, na.rm = TRUE)
)

# Exercise: Estimate and interpret all of the estimated model‘s outputs and diagnostics (are they different from OLS?)
summary(wls_model)

# =========================
# 5) ROBUST ESTIMATION: M-ESTIMATION (HUBER LOSS FUNCTION): SLIDE 14 
# =========================
robust_model <- rlm(
  unemp ~ gdp + htc + serv + den,
  data = data_model,
  psi = psi.huber,
  maxit = 100
)

# compute proxy p-values
robust_sum <- summary(robust_model)
robust_results <- as.data.frame(robust_sum$coefficients) %>%
  tibble::rownames_to_column("term") %>%
  rename(
    estimate = Value,
    std_error = `Std. Error`,
    t_value = `t value`
  ) %>%
  mutate(
    p_value_approx = 2 * (1 - pnorm(abs(t_value)))
  )
View(robust_results)

##########################################
### OPTIONAL
# Compare OLS, WLS and Robust coefficients
ols_results <- broom::tidy(ols_model) %>%
  dplyr::rename(
    estimate_ols = estimate,
    std_error_ols = std.error,
    p_value_ols = p.value
  ) %>%
  dplyr::select(
    term,
    estimate_ols,
    std_error_ols,
    p_value_ols
  )
wls_results <- broom::tidy(wls_model) %>%
  dplyr::rename(
    estimate_wls = estimate,
    std_error_wls = std.error,
    p_value_wls = p.value
  ) %>%
  dplyr::select(
    term,
    estimate_wls,
    std_error_wls,
    p_value_wls
  )

comparison <- robust_results %>%
  dplyr::select(
    term,
    estimate_robust = estimate,
    std_error_robust = std_error,
    p_value_approx
  ) %>%
  dplyr::left_join(
    ols_results,
    by = "term"
  ) %>%
  dplyr::left_join(
    wls_results,
    by = "term"
  )
View(comparison)
##########################################

# Exercise: Estimate and interpret all of the estimated model‘s outputs and diagnostics
summary(robust_model)

# =========================
# 6) GENERALISED METHOD OF MOMENTS (GMM): SLIDE 15
# =========================
# prepare data
data_gmm <- data_model %>%
  dplyr::filter(
    is.finite(unemp),
    is.finite(gdp),
    is.finite(htc),
    is.finite(serv),
    is.finite(den),
    is.finite(tertiary_education)
  )

# function, which defines conditions for GMM estimator
gmm_moments <- function(theta, data) {
  
  beta0 <- theta[1]
  beta1 <- theta[2]
  beta2 <- theta[3]
  beta3 <- theta[4]
  beta4 <- theta[5]
  
  y <- data$unemp
  
  X <- cbind(
    1,
    data$gdp,
    data$htc,
    data$serv,
    data$den
  )
  
  Z <- cbind(
    1,
    data$tertiary_education,
    data$htc,
    data$serv,
    data$den
  )
  
  beta <- c(beta0, beta1, beta2, beta3, beta4)
  
  e <- as.numeric(y - X %*% beta)
  
  # Moment conditions: E[Z'e] = 0
  g <- Z * e
  
  return(g)
}

# starting values from OLS
start_values <- coef(ols_model)

# estimate GMM
gmm_model <- gmm(
  g = gmm_moments,
  x = data_gmm,
  t0 = start_values
)

# Exercise: Estimate and interpret all of the estimated model‘s outputs and diagnostics
summary(gmm_model)

# =========================
# 7) QUANTILE MODEL: SLIDE 16
# =========================
qr25_model <- rq(
  unemp ~ gdp + htc + serv + den,
  tau = 0.25,
  data = data_model
)

qr50_model <- rq(
  unemp ~ gdp + htc + serv + den,
  tau = 0.50,
  data = data_model
)

qr75_model <- rq(
  unemp ~ gdp + htc + serv + den,
  tau = 0.75,
  data = data_model
)

# OPTIONAL: Plot of Observed vs Median (50th Quantile)
data_model <- data_model %>%
  mutate(
    fitted_q25 = fitted(qr25_model),
    fitted_q50 = fitted(qr50_model),
    fitted_q75 = fitted(qr75_model)
  )

ggplot(data_model, aes(x = fitted_q50, y = unemp)) +
  geom_point(size = 2, alpha = 0.7) +
  geom_abline(intercept = 0, slope = 1, colour = "red") +
  labs(
    title = "Quantile Regression (Median)",
    subtitle = "Observed vs Estimated Unemployment",
    x = "Estimated unemployment",
    y = "Observed unemployment"
  ) +
  theme_minimal()

# Exercise: Estimate and interpret all of the estimated model‘s outputs and diagnostics
# show results
summary(qr25_model)
summary(qr50_model)
summary(qr75_model)

# =========================
# 8) SPATIAL MODEL
# =========================

# out of scope

# =========================
# 9) LOG-LINEAR MODEL
# =========================
lin_log_model <- lm(
  unemp ~ ln_gdp + htc + serv + ln_den,
  data = data_model
)

# Note: For variables expressed in logarithms (GDP and population density), a 10% change 
# corresponds approximately to 0.1 × the estimated coefficient. 
# For variables measured as percentages (HTC and SERV), the coefficient represents 
# the effect of a one percentage-point increase in the explanatory variable.

# Exercises:
# 1. Use OLS to estimate the model in R  
# 2. Interpret all of the estimated model‘s outputs
# 3. Interpret the estimated model‘s parameters (are they economically sound?)

# show results
summary(lin_log_model)

# HOMEWORK: Use other estimation techniques – which one would you prefer in practice?
