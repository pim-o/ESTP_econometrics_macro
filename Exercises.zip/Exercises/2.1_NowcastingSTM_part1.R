##############################################################################################
# STM Nowcasting models for Banking and Insurance sectors 
##############################################################################################

#######
# Author : Pim Ouwehand (StatNL)

# Goal 	 : This script contains structural time series models used for nowcasting, in order to produce 
#          flash estimates for Banking and Insurance sectors, as part of the National Accounts 
#          The models make an estimates based on only partial information from the reference period. 
#######


rm(list=ls())
gc()


#-------------------------------------------------
# Loading packages etc.
#-------------------------------------------------

#install this package if not installed already (one time only):
#install.packages('KFAS')

#loading required packages 
library(KFAS) 
packageDescription("KFAS")$Version #check version (>1.4.4)

library(zoo)  #for na.trim.ts

# Several auxiliary functions required to perform the calculations in this script.  
source("Auxiliary/NowcastingSTM auxiliary functions.R")




#-------------------------------------------------
# Required settings
#-------------------------------------------------

# files with data 
datafile <- "data/Data_Bank_Insurance_STM.csv"

# starting date of series in input data / first period in the dataset 
firstquarter.data <- c(2010,1) #year, quarter 


# what is the first period you want to use to start your calculations? 
# should always be greater or equal than firstquarter.data 
firstquarter.model <- c(2010,1) 


# reporting period = period to be nowcasted
# this is in general one period after the last observation available for the target variable. 
nowcasting.period <- c(2019, 4) #year, quarter 


conf.level = 0.95  #for computing margins 








#-------------------------------------------------
# loading and preparing the data
#-------------------------------------------------

# read in all series 
data <- read.csv2(datafile)


# check if everything looks good
data

#----We first make quarterly time series starting in "firstquarter.data"
n <- names(data) 
data1 <- ts(data, start=firstquarter.data, frequency = 4, names=n) 
# Converting the data to time series is not required, but makes output more readable and producing 
# graphics more easy.


#----now select the right series from the inputdata  
target_series1 <- data1[, c("Index_Bank")] # series for Banking 
#target_series1 <- data1[, c("Index_Insurance")] 


#select the right periods
target_series <- window(target_series1, start=firstquarter.model, end=nowcasting.period, extend=TRUE) 



#----optional checks: 
target_series 
is.ts(target_series) # should be true 
tsp(target_series) # begin, end, and frequency of series
ts.plot(target_series)








###------------------------------------
### Fitting a model for Banking sector
###------------------------------------

# The Maximum Likelihood procedure needs starting values for the hyperparameters
startingvalues.all <- set.initials(0.1, 0, 0.1, 0, 0) 


#----- In-sample model selection

# we now make estimate several models, in order to select the best one: 
compare.models(target_series, NULL , startingvalues.all)$opt.model 

# for some models this may yield an error "Error in solve.default(-H) : "
# This is nothing severe, and has to do with computation of t-values 
# The rest of the computations are not affected. 


# Let's assume we decide that model 5 is the best model, and we want to use this model:
modelsel <- select.model(5, target_series, NULL ,startingvalues.all)


# The parameters are estimated via Maximum likelihood
ML <- TS.estimate.parameters(modelsel$model, modelsel$initial.values)


# Next, we apply the Kalman Filter in order to estimate unknown state variables:
SM <- TS.smooth(ML$fitmdl$model)


# Now that we estimated the model, let's check the model assumptions:
TS.diagnostics(modelsel$model, SM$out_KFS)


#we can plot the original series together with the model estimates 
tl <- SM$signalsubconf  #the trend
signal <- SM$signalconf #trend plus seasonal
# the signal is also required below for compution margins for the growth rate 
plotSM(target_series, tl, "Banking sector")


# filtered vs smoothed estimates:
out <- KFS(ML$fitmdl$model, filtering='state', smoothing='state')

filtered <- out$att
smoothed <- out$alphahat
plotSM(target_series, filtered[,1], "filtered vs smoothed")
lines(smoothed[,1], col=3, lwd=3)
#note: legend is not correct in this case



# Next, we can now use the model to make predictions
fittedmodel <- ML$fitmdl$model
predictions <- predict(fittedmodel, n.ahead=1,  interval="confidence") 
predictions


# The predict function uses the state estimates at the end of the time series
# in order to extrapolate. A trend model (e.g., model 5) thus yields a straight line with predictions: 
predictions <- predict(fittedmodel, n.ahead=5,  interval="confidence") 
ts.plot(cbind(target_series,predictions,SM$signalsubconf), col=c(1,2,2,2,3,3,3))





#-------------------------------------------
# Exercise:
#-------------------------------------------
# Try out other models as well; which model is the best and why?
# hint: 
# use the function compare.models()
# and look at the lowest AIC, signal variance (because of overfitting), 
#   significance of the hyperparameters for the disturbances, and all model assumptions 



#-------------------------------------------
# Exercise:
#------------------------------------------- 
# Find the best model for the time series of the Insurance sector ("Index_Insurance")




