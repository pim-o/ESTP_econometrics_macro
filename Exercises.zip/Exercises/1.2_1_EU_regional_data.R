# =========================
# PRESENTATION SLIDE 4: DATA IN R
# =========================

# =========================
# 1) Packages
# =========================
packages <- c("eurostat", "dplyr", "tidyr", "stringr", "purrr", "readr")
to_install <- packages[!packages %in% installed.packages()[, "Package"]]
if (length(to_install) > 0) install.packages(to_install)

library(eurostat)
library(dplyr)
library(tidyr)
library(stringr)
library(purrr)
library(readr)

options(eurostat_update = TRUE)

# =========================
# 2) Define functions - selection of NUTS 2, latest common year, lable text
# =========================

# keep only NUTS 2 regions
is_nuts2 <- function(x) {
  !is.na(x) & nchar(x) == 4 & !str_detect(x, "_")
}

# the latest common year across datasets
latest_common_year <- function(...) {
  years_list <- list(...)
  common <- Reduce(intersect, years_list)
  if (length(common) == 0) {
    stop("A common year not found across all economic indicators.")
  }
  max(common, na.rm = TRUE)
}

# robust selection of one category according to the text in the label
pick_by_label <- function(df, label_col, pattern) {
  out <- df %>%
    filter(str_detect(.data[[label_col]], regex(pattern, ignore_case = TRUE)))
  
  if (nrow(out) == 0) {
    stop(sprintf("Nenašla sa kategória podľa patternu: %s", pattern))
  }
  out
}

# =========================
# 3) Unemployment (tgs00010)
# =========================
unemp_raw <- get_eurostat("tgs00010", time_format = "num")
names(unemp_raw)

# check available dimensions
unemp_raw %>% 
  summarise(across(where(is.character), ~ paste(unique(.x), collapse = ", ")))

time_col <- intersect(c("time", "TIME_PERIOD"), names(unemp_raw))[1]
if (is.na(time_col)) stop("A column time not found.")

# safer filtering
unemp <- unemp_raw %>%
  filter(is_nuts2(geo)) %>%
  # keep these filters only if the columns exist
  { if ("sex"  %in% names(.)) filter(., sex == "T") else . } %>%
  { if ("age"  %in% names(.)) filter(., age == "Y15-74") else . } %>%
  { if ("unit" %in% names(.)) filter(., unit %in% c("PC_ACT", "PC")) else . } %>%
  { if ("isced11" %in% names(.)) filter(., isced11 == c("TOTAL")) else . } %>%
  transmute(
    geo,
    time = .data[[time_col]],
    unemployment = values
  ) %>%
  group_by(geo, time) %>%
  summarise(unemployment = first(na.omit(unemployment)), .groups = "drop")
View(unemp)

# =========================
# 4) GDP pre capita -- the most common selection for GDP per capita:
# =========================
# na_item = B1GQ (GDP at market prices) -- (nama_10r_2gdp)
# unit    = EUR_HAB (euro per inhabitant) -- (tgs00003)

gdp_raw <- get_eurostat("tgs00003", time_format = "num")
names(gdp_raw)

time_col <- intersect(c("time", "TIME_PERIOD"), names(gdp_raw))[1]
if (is.na(time_col)) stop("A column time not found.")

gdp <- gdp_raw %>%
  filter(is_nuts2(geo)) %>%
  transmute(
    geo,
    time = .data[[time_col]],
    gdp_eur_per_inhab = values
  )
View(gdp)

# =========================
# 5) Population density (tgs00024)
# =========================
density_raw <- get_eurostat("tgs00024", time_format = "num")
names(density_raw)

time_col <- intersect(c("time", "TIME_PERIOD"), names(density_raw))[1]
if (is.na(time_col)) stop("A column time not found.")

density <- density_raw %>%
  filter(is_nuts2(geo)) %>%
  transmute(
    geo,
    time = .data[[time_col]],
    population_density = values
  )
View(density)

# =========================
# 6) High-tech + knowledge-intensive services (htec_emp_reg2)
# =========================
# This dataset contains more detailed breakdown of NACE activities
# Hence, we show NACE on level of lables and filter according to the label's name
htec_raw <- get_eurostat("htec_emp_reg2", time_format = "num")
names(htec_raw)

time_col <- intersect(c("time", "TIME_PERIOD"), names(htec_raw))[1]
if (is.na(time_col)) stop("A column time not found.")

htec_labeled <- htec_raw %>%
  mutate(
    nace_r2_label = label_eurostat(
      nace_r2,
      dic = "nace_r2",
      fix_duplicated = TRUE
    ),
    unit_label = label_eurostat(
      unit,
      dic = "unit",
      fix_duplicated = TRUE
    )
  )

# Check the label's name and adjust the description in regex() below
View(htec_labeled)

# unit: percent of total employment
# the label usually contain "Percentage of total employment" or similar
htec_pct <- htec_labeled %>%
  filter(
    is_nuts2(geo),
    str_detect(unit_label, regex("percentage.*total employment|% of total employment", ignore_case = TRUE))
  )
View(htec_pct)

# HTC = percent of total employment in high-technology sectors
htc <- htec_pct %>%
  pick_by_label("nace_r2_label", "High-technology sectors") %>%
  transmute(
    geo,
    time = .data[[time_col]],
    htc = values,
    nace_r2_label
  )%>%
  distinct(geo, time, .keep_all = TRUE)
View(htc)

# SERV = percent of employment in knowledge-intensive services
serv <- htec_pct %>%
  pick_by_label("nace_r2_label", "Knowledge-intensive services") %>%
  transmute(
    geo,
    time = .data[[time_col]],
    serv = values,
    nace_r2_label
  )%>%
  distinct(geo, time, .keep_all = TRUE)
View(serv)

# =========================
# Control functions for duplicates and unique geo-time
# =========================
check_duplicates <- function(df, df_name) {
  dup <- df %>%
    count(geo, time, name = "n") %>%
    filter(n > 1)

  if (nrow(dup) > 0) {
    message("Dataset ", df_name, " has duplicates for geo-time: ", nrow(dup), " riadkov.")
    print(dup, n = 20)
  } else {
    message("Dataset ", df_name, " is OK: without duplicates for geo-time.")
  }
}

force_unique_geo_time <- function(df, value_col) {
  # keep only geo, time, value
  out <- df %>%
    select(geo, time, !!sym(value_col)) %>%
    filter(!is.na(geo), !is.na(time)) %>%
    group_by(geo, time) %>%
    summarise(
      !!value_col := dplyr::first(na.omit(.data[[value_col]])),
      .groups = "drop"
    )
  out
}

# =========================
# 7) Cleaning of datasets and checks for common year analysis
# =========================
unemp   <- force_unique_geo_time(unemp,   "unemployment")
View(unemp)

gdp     <- force_unique_geo_time(gdp,     "gdp_eur_per_inhab")
View(gdp)

density <- force_unique_geo_time(density, "population_density")
View(density)

htc     <- force_unique_geo_time(htc,     "htc")
View(htc)

serv    <- force_unique_geo_time(serv,    "serv")
View(serv)

check_duplicates(unemp,   "unemp")
check_duplicates(gdp,     "gdp")
check_duplicates(density, "density")
check_duplicates(htc,     "htc")
check_duplicates(serv,    "serv")

# checks for each economic indicator
list(
  unemp = unemp,
  gdp = gdp,
  density = density,
  htc = htc,
  serv = serv
) %>%
  imap(~{
    cat("\n====================\n")
    cat(.y, "\n")
    cat("====================\n")
    print(dim(.x))
    print(names(.x))
    cat("Years:\n")
    print(sort(unique(.x$time)))
    cat("number of geo:\n")
    print(n_distinct(.x$geo))
    cat("NA:\n")
    print(colSums(is.na(.x)))
    cat("duplicity geo-time:\n")
    print(.x %>% count(geo, time) %>% filter(n > 1) %>% nrow())
  })

# intersecting years
Reduce(intersect, list(
  unique(unemp$time),
  unique(gdp$time),
  unique(density$time),
  unique(htc$time),
  unique(serv$time)
))

# check the maximum availyble year
check_year <- function(df) max(df$time, na.rm = TRUE)
check_year(unemp)
check_year(gdp)
check_year(density)
check_year(htc)
check_year(serv)

# check the number of observations for available years
all_years <- sort(unique(c(
  unemp$time, gdp$time, density$time, htc$time, serv$time)))
for (yy in rev(all_years)) {
  tmp <- list(
    unemp   %>% filter(time == yy),
    gdp     %>% filter(time == yy),
    density %>% filter(time == yy),
    htc     %>% filter(time == yy),
    serv    %>% filter(time == yy)
  ) %>%
    reduce(inner_join, by = c("geo", "time"))
  
  cat("Year:", yy, " | a number of rows in inner_join:", nrow(tmp), "\n")
}

# =========================
# 8) The most recent common year
# =========================
latest_year <- latest_common_year(
  unemp$time,
  gdp$time,
  density$time,
  htc$time,
  serv$time
)

cat("The most common year in all economic indicators is:", latest_year, "\n")

# =========================
# 9) Dataset for the latest common year
# =========================
# keep only regions, which have all economic indicators available
data_latest <- list(unemp, gdp, density, htc, serv) %>%
  reduce(inner_join, by = c("geo", "time")) %>%
  filter(time == latest_year) %>%
  distinct(geo, time, .keep_all = TRUE) %>%
  arrange(geo)
View(data_latest)

# =========================
# 10) Delete missing values (entire region(s) removed if any missing)
# =========================
data_latest <- data_latest %>%
  filter(
    !is.na(unemployment),
    !is.na(gdp_eur_per_inhab),
    !is.na(population_density),
    !is.na(htc),
    !is.na(serv)
  )
View(data_latest)

# =========================
# 11) Additional checks
# =========================
data_latest_zero <- data_latest %>%
  filter(
    unemployment < 0 |
    gdp_eur_per_inhab < 0 |
    population_density < 0 |
    htc < 0 |
    serv < 0
  )
data_latest_zero

# =========================
# 12) Export data to .csv file
# =========================
# a number of regions in the final dataset
cat("The number of regions in the final dataset:", nrow(data_latest), "\n")

# export / re-import to csv
write_csv(data_latest, "F:/SOSR/ESTP Econometrics for Macroeconomic Statistics/data/eurostat_regional_data.csv")
data_latest <- read_csv("F:/SOSR/ESTP Econometrics for Macroeconomic Statistics/data/eurostat_regional_data.csv")
View(data_latest)