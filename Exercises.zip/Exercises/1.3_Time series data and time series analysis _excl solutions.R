##############################################################################################
# Time series data and applications 
##############################################################################################

#######
# Author : Pim Ouwehand (StatNL)

#######


rm(list=ls())
gc()


#-------------------------------------------------
# Loading packages etc.
#-------------------------------------------------


library(dplyr)
library(corrplot)
library(dplyr)
library(tidyr)
library(zoo)
library(tseries)
library(forecast)




#-------------------------------------------------
# read and prepare data
#-------------------------------------------------

data_month <- read.csv2('data/economic_series_month.csv')
data_quarter <- read.csv2('data/economic_series_quarter.csv')

# combine both datasets
data <- full_join(data_month, data_quarter, by='Period') 
data_num <- data %>% select(-Period) 

# for this exercise, we will interpolate the three quarterly series
# so that all series have monthly frequency
data_interp <- na.approx(data_num, na.rm = FALSE)
data_interp <- as.data.frame(data_interp)

# to avoid problems due to division by zero:
data_interp[data_interp == 0 ] = 0.01

# percentage change
data_growth <- data_interp %>%
  mutate(across(everything(), ~ (. / lag(.) - 1) * 100)) %>%
  drop_na() 




# =============================================================
# 1. Stationarity
# =============================================================



# *-*-*-*-*-*-*-*-*-*-*-*-*-*-
#EXERCISE: 
# *-*-*-*-*-*-*-*-*-*-*-*-*-*-
# try to make the following series stationary 
# use (seasonal) differencing, perhaps take a log 

data(AirPassengers)
ap <- AirPassengers

adf.test(ap)
#adf.test has a p-value below 0.05, so series seems stationary,
#but adf.test always includes a linear trend in the test regression. 
#The alternative hypothesis is therefore "trend-stationary," not "stationary."

library(urca)
# No constant, no trend
summary(ur.df(ap, type = "none", lags = 12))
#fail to reject the unit-root null hyp., so the test finds the series non-stationary.



# *-*-*-*-*-*-*-*-*-*-*-*-*-*-
# Solution: 
# *-*-*-*-*-*-*-*-*-*-*-*-*-*-








# =============================================================
# 3. Cointegration
# =============================================================




# *-*-*-*-*-*-*-*-*-*-*-*-*-*-
# EXERCISE: 
# *-*-*-*-*-*-*-*-*-*-*-*-*-*-

# consumption-quote
# prove that consumption and income are both nonstationary, but cointegrated.


data_Inc_Cons <- read.csv2("data/CBS_Consumption_Income.csv")  
#https://opendata.cbs.nl/#/CBS/nl/dataset/85881NED/table?ts=1784549394056


# ---1. define time series ---
cons_ts <- ts(data_Inc_Cons$Consumption, start = c(1999, 1), frequency = 4)
inc_ts  <- ts(data_Inc_Cons$Income,    start = c(1999, 1), frequency = 4)

# --- 2. log -transform  ---
log_cons <- log(cons_ts)
log_inc  <- log(inc_ts)

plot.ts(cbind(log_cons, log_inc), plot.type = "single",
        col = c("steelblue", "firebrick"),
        main = "Consumption and income (log)")
legend("topleft", legend = c("consumption", "income"),
       col = c("steelblue", "firebrick"), lty = 1)



#use this:
# --- step 1. first test for non-stationarity
adf.test(x)  # H0: non-stationary (unit root): p>0.05
adf.test(y)
adf.test(diff(x))  # first diff should be stationary p<0.05
adf.test(diff(y))

# --- Step 2: Engle-Granger test
po.test(cbind(y, x))  # Phillips-Ouliaris test  
  



# *-*-*-*-*-*-*-*-*-*-*-*-*-*-
# SOLUTION: 
# *-*-*-*-*-*-*-*-*-*-*-*-*-*-


# =============================================================
# 5. Temporal relations: leading/lagging series
# =============================================================





# ------------------------------------------------------------
# Granger causality test 
# ------------------------------------------------------------
# Tests whether past values of x help predict y, beyond y's own past.
# install.packages("lmtest") if not already installed.

library(lmtest)


data_econ <- data_interp %>% drop_na() 

adf.test(data_econ$Consumerconfidence)
adf.test(data_econ$GDP)
adf.test(diff(data_econ$Consumerconfidence))
adf.test(diff(data_econ$GDP))
# after differencing they are clearly (p=0.01) stationary
# so we work with the differenced series:
gdp_diff <- diff(data_econ$GDP)
consumerconfidence_diff <- diff(data_econ$Consumerconfidence)

# Does the consumer confidence Granger-cause GDP?
grangertest(gdp_diff ~ consumerconfidence_diff, order = 6)

# or the other way round?
grangertest(consumerconfidence_diff ~ gdp_diff, order = 6)

# so consumerconfidence Granger-causes GDP




# *-*-*-*-*-*-*-*-*-*-*-*-*-*-
# EXERCISE: 
# *-*-*-*-*-*-*-*-*-*-*-*-*-*-
library(ggplot2)
data(economics)
# Data: `economics` dataset from the ggplot2 package.
# Real monthly US macroeconomic series sourced from FRED
# (Federal Reserve Economic Data), 1967-2015.

# we study two series:
# pce : personal consumption expenditure 
# unemploy: number unemployed

par(mfrow = c(2, 1), mar = c(3, 4, 2, 1))
plot(economics$date, economics$pce, type = "l", col = "steelblue",
     xlab = "", ylab = "PCE (billions USD)",
     main = "Personal consumption expenditures")
plot(economics$date, economics$unemploy, type = "l", col = "darkorange",
     xlab = "", ylab = "Unemployed (thousands)",
     main = "Number of unemployed")
par(mfrow = c(1, 1))

# convert to time series objects (monthly data)
pce_ts      <- ts(economics$pce,      start = c(1967, 7), frequency = 12)
unemploy_ts <- ts(economics$unemploy, start = c(1967, 7), frequency = 12)


# Question:
# At which lag does the strongest correlation occur?
# Is it positive or negative? What does the sign tell you about
# which series leads and which one lags?

# Question:
# Is the peak correlation positive or negative in value?
# What would a negative correlation mean here, economically?
# (Think about what happens to unemployment when people save more.)

# Question:
# Based on the p-values, which direction (if either) shows
# significant Granger causality? Does this match the lag you
# found in the CCF plot?



# *-*-*-*-*-*-*-*-*-*-*-*-*-*-
# SOLUTION: 
# *-*-*-*-*-*-*-*-*-*-*-*-*-*-







