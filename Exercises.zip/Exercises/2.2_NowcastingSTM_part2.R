##############################################################################################
# STM Nowcasting models for Banking and Insurance sectors 
##############################################################################################

#######
# Author : Pim Ouwehand (StatNL)

# Goal 	 : This script contains structural time series models used for nowcasting, in order to produce 
#          flash estimates for Banking and Insurance sectors, as part of the National Accounts 
#          The models make an estimates based on only partial information from the reference period. 
#######


rm(list=ls())
gc()


#-------------------------------------------------
# Loading packages etc.
#-------------------------------------------------

#install this package if not installed already (one time only):
#install.packages('KFAS')

#loading required packages 
library(KFAS) 
packageDescription("KFAS")$Version #check version (1.4.4)

library(zoo)  #for na.trim.ts

# Several auxiliary functions required to perform the calculations in this script.  
source("Auxiliary/NowcastingSTM auxiliary functions.R")





#-------------------------------------------------
# Required settings
#-------------------------------------------------


# files with data 
datafile <- "Data/Data_Bank_Insurance_STM.csv"

# starting date of series in input data / first period in the dataset 
firstquarter.data <- c(2010,1) #year, quarter 


# what is the first period you want to use to start your calculations? 
# should always be greater or equal than firstquarter.data 
firstquarter.model <- c(2010,1) 


# reporting period = period to be nowcasted
# this is in general one period after the last observation available for the target variable. 
# in this case, to avoid complications around the covid-periods, 
# we will make a nowcast for 2019Q4:
nowcasting.period <- c(2019, 4) #year, quarter 


# we will do a crosvalidation on the last 4 periods, so we let it start
# 4 periods prior to nowcasting.period:
start.crosval <- c(2018,4)


conf.level = 0.95  #for computing margins 







#-------------------------------------------------
# loading and preparing the data
#-------------------------------------------------

# read in all series
data <- read.csv2(datafile)

# check if everything looks good
data

#----We first make quarterly time series starting in "firstquarter.data"
n <- names(data) 
data1 <- ts(data, start=firstquarter.data, frequency = 4, names=n) 

# Converting the data to time series is not required, but makes output more readable and producing 
# graphics more easy.




#----now select the right series from the inputdata   
target_series1.Bank <- data1[, c("Index_Bank")]
target_series1.Ins <- data1[, c("Index_Insurance")]
# and select the right regressor (assuming we know which one to incorporate in the model):
regressors1.Bank <- data1[, c("Creditcard_foreign_lag2")]# domestic_Lag2")]
regressors1.Ins <- data1[, c("Mortgages")]

# Below, we will also automatically determine which model, and which (combination of) regressor(s)
# delivers the best nowcast. The optimal combination is selected from the following set of 
# regressors: 
available.regressors1.Bank <- data1[, c("Creditcard_foreign_lag2", 
                                    "Debitcard_transactions",
                                    "Mortgages",
                                    "Cash_Deposits")] 

available.regressors1.Ins <- data1[, c("Policies_Car",
                                       "Mortgages",
                                       "LifeIns_Total",
                                       "IncomeIns")]



# More variables are available in the dataset.
# Description of all variables available in the dataset: 
#   
# Stockmarket_transactions:     Net value in millions of euros on AEX (Amsterdam stock exchange) 
# Mortgages: 	                  Number of mortgage contracts
# Debitcard_transactions:       Number of transactions / 1000		
# Euribor:                      3-month Euribor interest rate 	
# Payment transactions: 			
# - Creditcard_domestic:	      Number of credit card payments/ 1000	 	
# - Creditcard_foreign:         Number of credit card payments/ 1000	 	
# - Cash_deposits:      	      Number of cash deposits at bank / 1000	 	
# - Total_payment_transactions: Sum of above three 	
# 
# 
# 
# Vacancies:              	    Number of vacancies fulfilled
# LifeIns_Cash:              	  Number of individual life insurances, in particular capital insurances  
# LifeIns_Stock:                Same, but investment insurances 	 
# LifeIns_Total:                Sum of these two
# IncomeIns:                  	Number of income insurances in portfolio
# Policies_Car:                 New car insurance policies 
# Policies_Fire:                New fire insurance policies 
# Policies_Other:               Other new insurance policies 




#----optional checks: 
target_series1.Bank 
target_series1.Ins
regressors1.Bank 
regressors1.Ins 

available.regressors1.Bank 
available.regressors1.Ins 

ts.plot(target_series1.Bank)
ts.plot(target_series1.Ins)


#---- we now ensure that all series have the correct length for making the nowcast

# we assume that the target series is not available for the reference period (=period to be nowcasted)
# >> it therefore ends with an NA value.  
# on the other hand, we assume that the regressors are available for this period
# for example:
# ..   ..  target series  regressor
# 2020 Q1  5921       	  5134.54
# 2020 Q2  5599           4104.54
# 2020 Q3  5858           5076.00
# 2020 Q4    NA           4057.40

# the target series may have to be extended by one period: 
target_series.Bank <- window(target_series1.Bank, start=firstquarter.model, end=nowcasting.period, extend=TRUE) 
target_series.Ins <- window(target_series1.Ins, start=firstquarter.model, end=nowcasting.period, extend=TRUE) 

# the last value of the target series must be empty, if not already:
target_series.Bank[length(target_series.Bank)] <- NA # this line is optional 
target_series.Ins[length(target_series.Ins)] <- NA # this line is optional

# ensure that the regressors have correct starting and ending period.
# we assume these variables are already available for the nowcasting period.  
regressors.Bank <- window(regressors1.Bank, start=firstquarter.model, end=nowcasting.period) 
regressors.Ins <- window(regressors1.Ins, start=firstquarter.model, end=nowcasting.period) 
available.regressors.Bank <- window(available.regressors1.Bank, start=firstquarter.model, end=nowcasting.period) 
available.regressors.Ins <- window(available.regressors1.Ins, start=firstquarter.model, end=nowcasting.period) 





###--------------------------
### Nowcasting for Banking sector 
###--------------------------


#---- select one series and a regressor:
target_series <- target_series.Bank
#target_series <- target_series.Ins

regressor2 <- regressors.Bank
#regressor2 <- regressors.Ins


# rescaling the regressor in order to avoid numerical problems.  
# this is especially important for the MaxLik optimisation procedure. 
regressor <-   regressor2 / mean(regressor2, na.rm = T)
# if you do not want to use a regressor, use this line 
# regressor  <- cbind()


#----check
cbind(target_series, regressor)


# The Maximum Likelihood procedure needs starting values for the hyperparameters
startingvalues.all <- set.initials(0.1, 0, 0.1, 0, 0) 


# we now make estimate several models, in order to select the best one: 
compare.models(target_series, regressor , startingvalues.all)$opt.model 
# for some models this may yield an error "Error in solve.default(-H) : "
# This is nothing severe, and has to do with computation of t-values 
# The rest of the computations are not affected. 



# Let's assume we decide that model 5 is the best model, and we want to use this model:
modelsel <- select.model(5, target_series, regressor,startingvalues.all)
printsummary(modelsel, target_series, regressor)


# The parameters are estimated via Maximum likelihood
ML <- TS.estimate.parameters(modelsel$model, modelsel$initial.values)


# Next, we apply the Kalman Filter in order to estimate unknown state variables:
SM <- TS.smooth(ML$fitmdl$model)


# Now that we estimted the model, let's check the model assumptions:
TS.diagnostics(modelsel$model, SM$out_KFS)


# Next, we can plot the original series together with the model estimates 
tl <- SM$signalsubconf  #the trend
signal <- SM$signalconf #trend plus seasonal
# the signal is also required below for computing margins for the growth rate 
plotSM(target_series, tl, "Banking sector")



# Question: model 5 with regressor "Creditcard_foreign_lag2" gives a wave pattern in the fitted model when plotted
# What is the reason for this? 



#----nowcasting using the fitted model 
PR <- TS.nowcast(ML$fitmdl$model, conf.level) 

# This function makes nowcasts for the target variable. 
# These in fact result from the prediction step of the Kalman Filter, 
# and can be seen as an in-sample estimate, since for the Kalman Filter, 
# this is a missing data problem: the regressors are available, but the target variable 
# is missing for the nowcasting period.   


#----results
SM$signalsub  #smoothed trend
PR$predictions #predictions, up to the end of the sample
# the last value of PR$predictions contains the nowcast:
nowcast.Bank <- window(PR$predictions, start= tsp(PR$predictions)[2]) 
nowcast.Bank


#----plot of target series + signal + predictions
make.graph(target_series, PR$predictions, SM$signal, "Banking sector", conf.level)






###--------------------------
###  Cross-validation for Banking sector model 
###--------------------------


# The above steps are now combined into a function, which allows us to make nowcasts easily 
# The input required is a target series and one or more regressor(s) 
# The output is a variabele "nowcast"


make.nowcast.STM <- function(target_series.1, regressor.1, modelnumber=5){

  startingvalues.all <- set.initials(0.5, 0, 0.5, 0, 0)  
  modelsel <- select.model(modelnumber, target_series.1, regressor.1,startingvalues.all)
  printsummary(modelsel, target_series.1, regressor.1)
  ML <- TS.estimate.parameters(modelsel$model, modelsel$initial.values)
  SM <- TS.smooth(ML$fitmdl$model)
  PR <- TS.nowcast(ML$fitmdl$model, conf.level) 
  nowcast.series.margins <- window(PR$predictions, start= tsp(PR$predictions)[2]) 
  nowcast.series <- nowcast.series.margins[,1]
  
  return(list(nowcast=nowcast.series, nowcast.margins=nowcast.series.margins))
}

make.nowcast.STM(target_series.Bank, regressors.Bank, modelnumber=5) 




# Next, we write a function that performs cross validation on this model 
# With this function we can evaluate a model that is estimated via another function, 
# over a rolling horizon

evaluate.model <- function(series, regressor, modelnr, FUN, start.eval, eval.periods=4){
  
  #series <- target_series
  #start.eval=c(2014,1)
  #eval.periods=4
  
  nowcasts <- c()
  for (i in 0:(eval.periods-1)){
    #remove the last x periods.
    #i<-0
    enddate <- start.eval[1]+(start.eval[2]-1+i)/tsp(series)[3]
    series2 <- window(series, end=enddate)
    regressor2 <- c()
    if(!is.null(regressor)){regressor2 <- window(regressor, end = enddate)}
    #set last value of target series to empty 
    series3 <- series2 
    series2[length(series2)] <- NA                   
    
    print(cbind(series2,regressor2))
    a <- FUN(series2,regressor2, modelnr)
  
    actual <- series3[length(series3)]
    nowcast <- a$nowcast
    error <- nowcast-actual
    ac.nc.er <- cbind(actual, nowcast, error)
    nowcasts <- rbind(nowcasts, ac.nc.er)
    
  }
  print(nowcasts)
  
  err <- nowcasts[,"error"]
  RMSE <- sqrt(mean(err^2))
  ME <- mean(err)
  MAPE <- mean(abs(err)/ nowcasts[,"actual"]) *100
  
  q.measures <- cbind(RMSE, ME, MAPE)
  enddate2 <- start.eval[1]+(start.eval[2]-1+eval.periods)/tsp(series)[3]
  print(paste0("quality measures for periods ",start.eval[1], "Q",
               start.eval[2], " to ", floor(enddate2), "Q",  
               (enddate2%%floor(enddate2))*4 ))
  return(list(q.measures=q.measures)) 
  
}


# We now subsitute the first function into the second in order to perform 
# cross validation for a specific model :

evaluate.model(target_series.Bank, regressors.Bank, modelnr=5, FUN=make.nowcast.STM, 
                        start=start.crosval, eval.periods=4)

# The result is printed in the last line: RMSE, ME and MAPE for the selected model





#------------------------------
# Determine the best model + regressor 
#------------------------------

# Above we determine the performance (RMSE, ME, MAPE) of a specific model and specific (set) of regressor(s)
# We would also like to establish for a give target series what is the best (set) of regressor(s),
# in combination with which time series model. 
# We can do this by calculation the results for all model+regressor combinations 


# all combinations of available regressors: 
reg <- colnames(available.regressors.Bank)
#reg <- colnames(available.regressors.Ins)
all.regr.combinations <- generate_models(reg)
all.regr.combinations
length(all.regr.combinations)


target_series <- target_series.Bank
#target_series <- target_series.Ins

start <- Sys.time()

#!!: THIS FOR LOOP TAKES SEVERAL MINUTES: 
crosval.summary <- c()
for(modelnumber in 1:15){  
  for (i in 1:length(all.regr.combinations)){
    
    regressors <- c()
    reg.combi <- all.regr.combinations[[i]]
    if(!is.null(reg.combi)){regressors <- data1[,all.regr.combinations[[i]]]}
    
    cat("\n-------------------------------")
    cat("\nmodel number: ", modelnumber)
    cat("\nregressors: ", reg.combi )
    cat("\n-------------------------------\n")
    
    
    crossval <- evaluate.model(target_series, regressors, modelnumber, FUN=make.nowcast.STM, 
                               start=start.crosval, eval.periods=4)
    if(is.null(reg.combi)) reg.combi <- 0
    results<- c(round(crossval$q.measures,5), modelnumber, paste(reg.combi, collapse = " + "))
    names(results) <- c("RMSE", "ME", "MAPE", "modelnr", "reg")
    
    crosval.summary <- rbind(crosval.summary, results)
    
    
  }
}

end <- Sys.time()
end-start

# the 10 models with the lowest RMSE's:
crosval.summary =  as.data.frame(crosval.summary)
crosval.summary[order(as.numeric(crosval.summary$RMSE)),][1:10,]
crosval.summary[order(as.numeric(crosval.summary$MAPE)),][1:10,]


write.csv(crosval.summary, file="crosvalidation banking 2020Q4.csv")


###------------------------------------------------------------------------------------
### Exercise 1: Insurance sector 
###------------------------------------------------------------------------------------


# make a nowcast for 2019Q4 using the best model and regressors 

nowcasting.period <- c(2019, 4) #year, quarter 




###------------------------------------------------------------------------------------
### Exercise 2: Banking sector 
###------------------------------------------------------------------------------------
# Make a nowcast for 2020Q4, by selecting the best model, regressors and outliers
# What is your opinion on nowcasting a crisis period?  

nowcasting.period <- c(2020, 4) #year, quarter 




###------------------------------------------------------------------------------------
### Exercise 3: Insurance sector with outlier
###------------------------------------------------------------------------------------
# In 2020, the Covid-19 pandemic is clearly visible in the target series
# make a nowcast for 2020Q4
# assume that the extremely low value of 2020Q1 is an (Additive) outlier
# Add an outlier to the model (model a dummy variable as a regressor)


nowcasting.period <- c(2020, 4) #year, quarter 

dummy2020Q1 = target_series.Ins*0
dummy2020Q1[44] = 0
dummy2020Q1[41] = 1 


target_series <- target_series.Ins
regressors <- dummy2020Q1








###------------------------------------------------------------------------------------
### SOLUTIONS  
###------------------------------------------------------------------------------------



















###------------------------------------------------------------------------------------
### Exercise 1: Insurance sector 
###------------------------------------------------------------------------------------


# make a nowcast for 2019Q4 using the best model and regressors 

# auxiliary variables for insurance are only available from 2014, so the model
#  can only start from that period:
firstquarter.model <- c(2014,4) 


target_series.Ins <- window(target_series1.Ins, start=firstquarter.model, end=nowcasting.period, extend=TRUE) 

# the last value of the target series must be empty, if not already:
target_series.Ins[length(target_series.Ins)] <- NA # this line is optional

# ensure that the regressors have correct starting and ending period.
# we assume these variables are already available for the nowcasting period.  
regressors.Ins <- window(regressors1.Ins, start=firstquarter.model, end=nowcasting.period) 
available.regressors.Ins <- window(available.regressors1.Ins, start=firstquarter.model, end=nowcasting.period) 


#next continue above and execute 'Determine the best model + regressor' 


# all combinations of available regressors: 
reg <- colnames(available.regressors.Ins)
all.regr.combinations <- generate_models(reg)
all.regr.combinations
length(all.regr.combinations)


target_series <- target_series.Ins

data1 <- available.regressors.Ins

#!!: THIS FOR LOOP TAKES SEVERAL MINUTES: 
crosval.summary <- c()
for(modelnumber in 1:15){  
  for (i in 1:length(all.regr.combinations)){
    
    regressors <- c()
    reg.combi <- all.regr.combinations[[i]]
    if(!is.null(reg.combi)){regressors <- data1[,all.regr.combinations[[i]]]}
    
    cat("\n-------------------------------")
    cat("\nmodel number: ", modelnumber)
    cat("\nregressors: ", reg.combi )
    cat("\n-------------------------------\n")
    
    # modelnumber  <- 2
    crossval <- evaluate.model(target_series, regressors, modelnumber, FUN=make.nowcast.STM, 
                               start=start.crosval, eval.periods=4)
    if(is.null(reg.combi)) reg.combi <- 0
    results<- c(round(crossval$q.measures,5), modelnumber, paste(reg.combi, collapse = " + "))
    names(results) <- c("RMSE", "ME", "MAPE", "modelnr", "reg")
    
    crosval.summary <- rbind(crosval.summary, results)
    
    
  }
}

#crosval.summary.1 <- crosval.summary
#crosval.summary <- crosval.summary.1

# the 10 models with the lowest RMSE's:
crosval.summary =  as.data.frame(crosval.summary)
crosval.summary[order(as.numeric(crosval.summary$RMSE)),][1:10,]
crosval.summary[order(as.numeric(crosval.summary$MAPE)),][1:10,]






#once we established the best model + regressor, make a nowcast:
regressor <- available.regressors.Ins[,'Mortgages']

make.nowcast.STM(target_series.Ins, regressor, modelnumber=1) 





###------------------------------------------------------------------------------------
### Exercise 2: Banking sector 
###------------------------------------------------------------------------------------
# Make a nowcast for 2020Q4, by selecting the best model, regressors and outliers
# What is your opinion on nowcasting a crisis period?  

firstquarter.model <- c(2010,1) 
nowcasting.period <-  c(2020, 4) #year, quarter 




target_series.Bank <- window(target_series1.Bank, start=firstquarter.model, end=nowcasting.period, extend=TRUE) 
available.regressors.Bank <- window(available.regressors1.Bank, start=firstquarter.model, end=nowcasting.period) 





#next continue above and execute 'Determine the best model + regressor' 



#crosval.summary.2 <- crosval.summary
#crosval.summary <- crosval.summary.2

# the 10 models with the lowest RMSE's:
crosval.summary =  as.data.frame(crosval.summary)
crosval.summary[order(as.numeric(crosval.summary$RMSE)),][1:10,]
crosval.summary[order(as.numeric(crosval.summary$MAPE)),][1:10,]




#once we established the best model + regressor, make a nowcast:
regressor <- available.regressors.Bank[,c('Cash_Deposits','Debitcard_transactions','Mortgages')]

make.nowcast.STM(target_series.Bank, regressor, modelnumber=4) 





###------------------------------------------------------------------------------------
### Exercise 3: Insurance sector with outlier
###------------------------------------------------------------------------------------
# In 2020, the Covid-19 pandemic is clearly visible in the target series
# make a nowcast for 2020Q4
# assume that the extremely low value of 2020Q1 is an (Additive) outlier
# Add an outlier to the model (model a dummy variable as a regressor)


nowcasting.period <- c(2020, 4) #year, quarter 

target_series1.Ins <- data1[, c("Index_Insurance")]

dummy2020Q1 = target_series1.Ins*0
dummy2020Q1[44] = 0
dummy2020Q1[41] = 1 


regressors <- dummy2020Q1
regressors <- c()


make.nowcast.STM(target_series1.Ins, regressors, modelnumber=5) 



