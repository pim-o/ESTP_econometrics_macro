#################################################
# Simulation of Electronic Toll Records
#################################################

# Required packages
#install.packages("dplyr")
#install.packages("lubridate")
#install.packages("tidyr")
#install.packages("fixest")
#install.packages("ggplot2")

library(dplyr)
library(lubridate)
library(tidyr)
library(fixest)
library(ggplot2)
library(EMD)

set.seed(123)

# 60 months
months <- seq(
  as.Date("2019-01-01"),
  by = "month",
  length.out = 60
)

n_months <- length(months)

# 50000 potential trucks
n_trucks <- 50000

truck_info <- data.frame(
  VehicleID = sprintf("TR%04d", 1:n_trucks),

  # permanent truck-specific activity level
  base_activity = rlnorm(
    n_trucks,
    meanlog = log(25),
    sdlog = 0.55
  ),

  # heterogeneous truck-specific trend
  truck_trend = rnorm(
    n_trucks,
    mean = 0.002,
    sd = 0.004
  )
)

View(truck_info)

# -------------------------
# VEHICLE ENTRY AND EXIT
# -------------------------

truck_info <- truck_info %>%
  mutate(

    # 70% of vehicles are already active in month 1
    initially_active = rbinom(
      n_trucks,
      size = 1,
      prob = 0.70
    ),

    # Remaining vehicles enter randomly later
    entry_month = ifelse(
      initially_active == 1,
      1,
      sample(
        2:n_months,
        n_trucks,
        replace = TRUE
      )
    ),

    # Random duration of activity
    active_length = sample(
      12:40,
      n_trucks,
      replace = TRUE
    ),

    exit_month = pmin(
      entry_month + active_length - 1,
      n_months
    )
  ) %>%
  dplyr::select(-initially_active)

View(truck_info)

# =========================
# CREATE ACTIVE VEHICLE-MONTH PANEL
# =========================

monthly_data <- expand_grid(
  VehicleID = truck_info$VehicleID,
  MonthID = 1:n_months
) %>%
  left_join(
    truck_info,
    by = "VehicleID"
  ) %>%
  filter(
    MonthID >= entry_month,
    MonthID <= exit_month
  ) %>%
  mutate(
    Month = months[MonthID]
  )

View(monthly_data)

# =========================
# COMMON ECONOMIC COMPONENTS
# =========================

monthly_factors <- data.frame(
  MonthID = 1:n_months
) %>%
  mutate(

    # general upward trend
    macro_trend = 1 + 0.004 * MonthID,

    # annual seasonality
    seasonality =
      1 +
      0.12 * sin(2 * pi * MonthID / 12) +
      0.04 * cos(2 * pi * MonthID / 6),

    # temporary COVID-style shock
    shock = case_when(
      MonthID %in% 16:18 ~ 0.72,
      MonthID %in% 19:21 ~ 0.88,
      MonthID %in% 22:24 ~ 0.96,
      TRUE ~ 1
    ),

    # later stronger expansion
    late_growth = ifelse(
      MonthID >= 35,
      1 + 0.012 * (MonthID - 34),
      1
    )
  )

View(monthly_factors)

monthly_data <- monthly_data %>%
  left_join(
    monthly_factors,
    by = "MonthID"
  ) %>%
  mutate(

    # Truck-specific trend
    individual_growth =
      exp(truck_trend * MonthID),

    # Expected number of passages
    lambda =
      base_activity *
      macro_trend *
      seasonality *
      shock *
      late_growth *
      individual_growth,

    # Random variation
    lambda =
      lambda *
      exp(rnorm(n(), 0, 0.20)),

    # Monthly passages
    Passages =
      rpois(
        n(),
        lambda = pmax(lambda, 0.5)
      ),

    # -------- NEW --------
    # Random road section
    RoadSection =
      sample(
        paste0("R", sprintf("%04d", 1:1000)),
        n(),
        replace = TRUE
      )
  ) %>%
  filter(Passages > 0) %>%
  select(VehicleID,
    Month,
    MonthID,
    RoadSection,
    Passages
  )

View(monthly_data)

View(monthly_data %>%
  group_by(Month) %>%
  summarise(
    n_vehicles = n_distinct(VehicleID),
    .groups = "drop"
  ))

#################################################
# Fixed-base Jevons Index
#################################################

base_month <- monthly_data %>%
              filter(Month==min(Month)) %>%
              select(VehicleID, Base=Passages)

View(base_month)

jevons_data <- monthly_data %>%
               right_join(base_month, by="VehicleID")

View(jevons_data)

jevons_index <- jevons_data %>%
                group_by(Month) %>%
                summarise(Jevons=exp(mean(log(Passages/Base),
                          na.rm=TRUE)))

View(jevons_index)

#################################################
# Chained Jevons
#################################################

months <- sort(unique(monthly_data$Month))

chain <- numeric(length(months))

chain[1] <- 1

for(i in 2:length(months)){
    prev <- monthly_data %>%
    filter(Month==months[i-1])

    curr <- monthly_data %>%
    filter(Month==months[i])

matched <- inner_join(prev, curr, by="VehicleID",
                      suffix=c("_0","_1"))

movement <- exp(mean(log(matched$Passages_1/matched$Passages_0)))

chain[i] <- chain[i-1]*movement

}

chain_index <- data.frame(Month=months,
                          Chain=chain)

View(chain_index)

# =========================
# TPD INDEX WITH MOVEMENT SPLICE
# Window T = 25 months
# Total series = 60 months
# =========================

# Make sure Month is ordered
monthly_data <- monthly_data %>%
  arrange(Month) %>%
  mutate(
    VehicleID = factor(VehicleID)
  )

# Unique calendar months
all_months <- sort(unique(monthly_data$Month))

# Length of the multilateral window
T_window <- 25

# 1. Function for estimating TPD within one 25-month window
estimate_tpd_window <- function(data_window) {

  # months within this particular window
  months_window <- sort(unique(data_window$Month))

  # create a local month identifier: 1,...,25
  data_window <- data_window %>%
    mutate(
      MonthID = match(Month, months_window)
    )

  # TPD fixed-effects model
  tpd_model <- feols(
    log(Passages) ~ i(MonthID, ref = 1) | VehicleID,
    data = data_window
  )

  # estimated time effects
  b <- coef(tpd_model)

  # first month is base = 1
  tpd_values <- c(
    1,
    exp(b)
  )

  # return within-window indices
  data.frame(
    Month = months_window,
    TPD = tpd_values
  )
}

# 2. Estimate the first 25-month window
# =========================
# FIRST WINDOW
# =========================

window_1_months <- all_months[1:T_window]

data_window_1 <- monthly_data %>%
  filter(Month %in% window_1_months)

tpd_first <- estimate_tpd_window(data_window_1)

View(tpd_first)

# initial published index
tpd_spliced <- tpd_first %>%
  rename(Index = TPD)

# 3. Shift the window and apply Movement Splice
# =========================
# MOVEMENT SPLICE
# =========================

n_windows <- length(all_months) - T_window + 1

for (w in 2:n_windows) {

  # 25-month rolling window
  window_months <- all_months[
    w:(w + T_window - 1)
  ]

  data_window <- monthly_data %>%
    filter(Month %in% window_months)

  # estimate TPD within current window
  tpd_window <- estimate_tpd_window(data_window)

  # latest two TPD values in current window
  tpd_previous <- tpd_window$TPD[nrow(tpd_window) - 1]
  tpd_current  <- tpd_window$TPD[nrow(tpd_window)]

  # latest month-to-month movement
  movement <- tpd_current / tpd_previous

  # previously published index
  previous_published <- tail(tpd_spliced$Index, 1)

  # movement-spliced new index
  new_index <- previous_published * movement

  # new calendar month
  new_month <- tail(window_months, 1)

  # append only the new month
  tpd_spliced <- bind_rows(
    tpd_spliced,
    data.frame(
      Month = new_month,
      Index = new_index
    )
  )
}

View(tpd_spliced)

#################################################
## Join all indices
#################################################

comparison <- tpd_spliced %>%
  rename(
    TPD = Index
  ) %>%
  left_join(
    chain_index %>%
      rename(
        Chained = Chain
      ),
    by = "Month"
  ) %>%
  left_join(
    jevons_index %>%
      rename(
        Jevons = Jevons
      ),
    by = "Month"
  )

View(comparison)

#################################################
## Simulated Industrial Production Index
#################################################

comparison <- comparison %>%
  mutate(
    IPI =
      TPD +
      rnorm(
        n(),
        mean = 0,
        sd = 0.03
      )
  )

View(comparison)

ggplot(comparison, aes(x = Month)) +

  geom_line(
    aes(y = Jevons, colour = "Fixed-base Jevons"),
    linewidth = 1.1
  ) +

  geom_line(
    aes(y = Chained, colour = "Chained Jevons"),
    linewidth = 1.1
  ) +

  geom_line(
    aes(y = TPD, colour = "TPD"),
    linewidth = 1.1
  ) +

  geom_line(
    aes(y = IPI, colour = "IPI"),
    linewidth = 1.2,
    linetype = "dashed"
  ) +

  labs(
    title = "Comparison of Truck-Passage Indices",
    subtitle = "Fixed-base Jevons, Chained Jevons, Time Product Dummy and Industrial Production Index",
    x = "Month",
    y = "Index",
    colour = ""
  ) +

  theme_minimal()

#################################################
## Empirical Mode Decomposition
#################################################

emd_result <- emd(comparison$IPI)

#################################################
## IMF1
#################################################

imf1 <- emd_result$imf[,1]

plot(comparison$Month, imf1, type="l", lwd=2,
     main="Intrinsic Mode Function 1", xlab="Month", ylab="IMF1")
abline(h=0, lty=2)

#################################################
## IMF2
#################################################

imf2 <- emd_result$imf[,2]

plot(comparison$Month, imf2, type="l", lwd=2, col="blue",
     main="Intrinsic Mode Function 2", xlab="Month", ylab="IMF2")
abline(h=0,lty=2)

#################################################
## IMF3
#################################################

imf3 <- emd_result$imf[,3]

plot(comparison$Month, imf3, type="l", lwd=2, col="red",
     main="Intrinsic Mode Function 3", xlab="Month", ylab="IMF3" )
abline(h=0,lty=2)

###########################################################
## EXCERCISE: DECOMPOSE THE ESTIMATED TRUCK PASSAGE INDICES 
## AND MAKE A PLOT WITH DECOMPOSED IPI
###########################################################